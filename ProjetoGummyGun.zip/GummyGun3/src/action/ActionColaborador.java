package action;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ColaboradorDAO;
import model.Colaborador;


public class ActionColaborador extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session = request.getSession();
		
		String nomeColaborador = request.getParameter("txtnomeColaborador");
		String cpfColaborador1 = request.getParameter("txtcpfColaborador");
		long cpfColaborador = Long.parseLong(cpfColaborador1);
		String profissaoColaborador = request.getParameter("txtprofissaoColaborador");
		String telColaborador = request.getParameter("txttelColaborador");
		String emailColaborador = request.getParameter("txtemailColaborador");
		String enderecoColaborador = request.getParameter("txtenderecoColaborador");
		String registroColaborador = request.getParameter("txtregistroColaborador");
		int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
		
		Colaborador colaborador = new Colaborador();
		
		colaborador.setNomeColaborador(nomeColaborador);
		colaborador.setCpfColaborador(cpfColaborador);
		colaborador.setProfissaoColaborador(profissaoColaborador);
		colaborador.setTelColaborador(telColaborador);
		colaborador.setEmailColaborador(emailColaborador);
		colaborador.setEnderecoColaborador(enderecoColaborador);
		colaborador.setRegistroColaborador(registroColaborador);
		colaborador.setUsuario_idUsuario(usuario_idUsuario);
		
		ColaboradorDAO dao = new ColaboradorDAO();
		
		try {
			dao.incluir(colaborador);
			RequestDispatcher rd = request.getRequestDispatcher("/successCadastro.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
