package action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import dao.ColaboradorDAO;
import dao.CursoDAO;
import dao.TurmasDeCursosDAO;

import model.Colaborador;
import model.Curso;
import model.TurmasDeCurso;

public class ActionTurma extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");

		String nomeTurma = request.getParameter("txtnomeTurma");
		String Curso_idCurso1 = request.getParameter("txtCurso_idCurso");
		int curso_idCurso = Integer.parseInt(Curso_idCurso1);
		String Colaborador_idColaborador1 = request.getParameter("txtColaborador_idColaborador");
		int colaborador_idColaborador = Integer.parseInt(Colaborador_idColaborador1);
		String localTurma = request.getParameter("txtlocalTurma");
		String horarioTurma = request.getParameter("txthorarioTurma");
		String dataTurma = request.getParameter("txtdataTurma");

		String cmdIncluir = request.getParameter("cmdIncluir");
		String cmdPesquisar = request.getParameter("cmdPesquisar");
		String nomeCurso = request.getParameter("txtnomeCurso");
		TurmasDeCurso turma = new TurmasDeCurso();

		turma.setNomeTurma(nomeTurma);
		turma.setColaborador_idColaborador(colaborador_idColaborador);
		turma.setCurso_idCurso(curso_idCurso);
		turma.setLocalTurma(localTurma);
		turma.setHorarioTurma(horarioTurma);
		turma.setDataTurma(dataTurma);
		turma.setUsuario_idUsuario(usuario_idUsuario);

		if (cmdIncluir != null) {
			
			TurmasDeCursosDAO dao = new TurmasDeCursosDAO();
			try {
				dao.incluir(turma);
				RequestDispatcher rd = request.getRequestDispatcher("/successCadastro.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (cmdPesquisar.equalsIgnoreCase("turmacurso") ) {

			Curso curso = new Curso();

			CursoDAO cursodao = new CursoDAO();

			ColaboradorDAO colaboradorDAO = new ColaboradorDAO();

			curso.setNomeCurso(nomeCurso);

			ArrayList<Curso> listaCursos = new ArrayList<Curso>();
			
			ArrayList<Colaborador> listaColaboradores = new ArrayList<Colaborador>();

			if (nomeCurso != null) {
				listaCursos = cursodao.pesquisaCursos(curso);

				if (listaCursos != null) {
					request.setAttribute("listaCursos", listaCursos);
					RequestDispatcher rd = request.getRequestDispatcher("/cadastraTurma.jsp");
					rd.forward(request, response);

				}

			} else {
				listaCursos = cursodao.retornaTodosCursos();
				listaColaboradores = colaboradorDAO.retornaTodosColaboradores();
				
				if (listaCursos != null) {
					request.setAttribute("listaCursos", listaCursos);
					
					request.setAttribute("listaColaboradores", listaColaboradores);
					RequestDispatcher rd = request.getRequestDispatcher("/cadastraTurma.jsp");
					rd.forward(request, response);
				}
			}
		}

	}

}
