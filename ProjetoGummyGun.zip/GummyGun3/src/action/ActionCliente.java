package action;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDAO;
import model.Cliente;

public class ActionCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		String nomeCliente = request.getParameter("txtnomeCliente");
		String cpfCnpjCliente1 = request.getParameter("txtcpfCnpjCliente");
		long cpfCnpjCliente = Long.parseLong(cpfCnpjCliente1);
		String emailCliente = request.getParameter("txtemailCliente");
		String rgCliente = request.getParameter("txtrgCliente");
		String dataNascCliente = request.getParameter("txtdataNascCliente");
		String endCliente = request.getParameter("txtendCliente");
		String telCliente = request.getParameter("txttelCliente");
		String celCliente = request.getParameter("txtcelCliente");
		String protocoloCliente = request.getParameter("txtprotocoloCliente");
		String dataCadastroCliente = request.getParameter("txtdataCadastroCliente");
		int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");

		
		String cmdIncluir = request.getParameter("cmdCadastar");
		

		Cliente cliente = new Cliente();

		cliente.setNomeCliente(nomeCliente);
		cliente.setCpfCnpjCliente(cpfCnpjCliente);
		cliente.setEmailCliente(emailCliente);
		cliente.setRgCliente(rgCliente);
		cliente.setDataNascCliente(dataNascCliente);
		cliente.setEndCliente(endCliente);
		cliente.setTelCliente(telCliente);
		cliente.setCelCliente(celCliente);
		cliente.setProtocoloCliente(protocoloCliente);
		cliente.setDataCadastroCliente(dataCadastroCliente);
		cliente.setUsuario_idUsuario(usuario_idUsuario);

		ClienteDAO clientedao = new ClienteDAO();
		
		
		
		if (cmdIncluir.equalsIgnoreCase("Cadastrar")) {

			try {

				clientedao.incluir(cliente);

				RequestDispatcher rd = request.getRequestDispatcher("/successCadastro.jsp");
				rd.forward(request, response);

			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		
		
	}
}
