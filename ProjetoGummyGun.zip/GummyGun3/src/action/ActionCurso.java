package action;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CursoDAO;
import model.Curso;


public class ActionCurso extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		String nomeCurso = request.getParameter("txtnomeCurso");
		String categoriaCurso = request.getParameter("txtcategoriaCurso");
		String valorCurso1 = request.getParameter("txtvalorCurso");
		double valorCurso = Double.parseDouble(valorCurso1);
		int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
		
		Curso curso = new Curso();
		
		curso.setNomeCurso(nomeCurso);
		curso.setCategoriaCurso(categoriaCurso);
		curso.setValorCurso(valorCurso);
		curso.setUsuario_idUsuario(usuario_idUsuario);
		
		CursoDAO dao = new CursoDAO();
		
		try {
			dao.incluir(curso);
			RequestDispatcher rd = request.getRequestDispatcher("/successCadastro.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
