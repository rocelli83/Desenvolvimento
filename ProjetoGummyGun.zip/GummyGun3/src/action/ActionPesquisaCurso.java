package action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClienteDAO;
import dao.ColaboradorDAO;
import dao.CursoDAO;
import model.Cliente;
import model.Colaborador;
import model.Curso;

public class ActionPesquisaCurso extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String nomeCurso = request.getParameter("txtnomeCurso");
		String cmdPesquisar = request.getParameter("cmdPesquisar");

		if (cmdPesquisar.equalsIgnoreCase("Excluir")) {

			Curso curso = new Curso();

			CursoDAO cursodao = new CursoDAO();

			curso.setNomeCurso(nomeCurso);

			ArrayList<Curso> listaCursos = new ArrayList<Curso>();
			if (nomeCurso.isEmpty()) {

				listaCursos = cursodao.retornaTodosCursos();
				if (listaCursos != null) {
					request.setAttribute("listaCursos", listaCursos);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirCurso.jsp");
					rd.forward(request, response);

				}

			} else {
			listaCursos = cursodao.pesquisaCursos(curso);

			if (listaCursos != null) {
				request.setAttribute("listaCursos", listaCursos);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirCurso.jsp");
				rd.forward(request, response);

			}

		}
		}
		else if (cmdPesquisar.equalsIgnoreCase("Alterar")) {

			Curso curso = new Curso();

			CursoDAO cursodao = new CursoDAO();

			curso.setNomeCurso(nomeCurso);

			ArrayList<Curso> listaCursos = new ArrayList<Curso>();
			if (nomeCurso.isEmpty()) {

				listaCursos = cursodao.retornaTodosCursos();
				if (listaCursos != null) {
					request.setAttribute("listaCursos", listaCursos);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarCurso.jsp");
					rd.forward(request, response);

				}

			} else {
			listaCursos = cursodao.pesquisaCursos(curso);

			if (listaCursos != null) {
				request.setAttribute("listaCursos", listaCursos);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarCurso.jsp");
				rd.forward(request, response);

			}
		} }else if (cmdPesquisar.equalsIgnoreCase("Pesquisar")) {

			Curso curso = new Curso();

			CursoDAO cursodao = new CursoDAO();

			curso.setNomeCurso(nomeCurso);

			ArrayList<Curso> listaCursos = new ArrayList<Curso>();
			if (nomeCurso.isEmpty()) {

				listaCursos = cursodao.retornaTodosCursos();
				if (listaCursos != null) {
					request.setAttribute("listaCursos", listaCursos);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaCurso.jsp");
					rd.forward(request, response);

				}

			} else {
			listaCursos = cursodao.pesquisaCursos(curso);

			if (listaCursos != null) {
				request.setAttribute("listaCursos", listaCursos);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaCurso.jsp");
				rd.forward(request, response);

			}

		}} else if (cmdPesquisar.equalsIgnoreCase("turmacurso")) {

			Curso curso = new Curso();

			CursoDAO cursodao = new CursoDAO();
			
		
			ClienteDAO clientedao = new ClienteDAO();
			
			
			ColaboradorDAO colaboradorDAO = new ColaboradorDAO();

			curso.setNomeCurso(nomeCurso);

			ArrayList<Curso> listaCursos = new ArrayList<Curso>();
			ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();
			ArrayList<Colaborador> listaColaboradores = new ArrayList<Colaborador>();
			
			if (nomeCurso != null) {
					listaCursos = cursodao.pesquisaCursos(curso);

					if (listaCursos != null) {
						request.setAttribute("listaCursos", listaCursos);
						RequestDispatcher rd = request.getRequestDispatcher("/turmas.jsp");
						rd.forward(request, response);

					}

				} else {
				listaCursos = cursodao.retornaTodosCursos();
				listaColaboradores = colaboradorDAO.retornaTodosColaboradores();
				listaClientes = clientedao.retornaTodosClientes();
				if (listaCursos != null) {
					request.setAttribute("listaCursos", listaCursos);
					request.setAttribute("listaClientes", listaClientes);
					request.setAttribute("listaColaboradores", listaColaboradores);
					RequestDispatcher rd = request.getRequestDispatcher("/turmas.jsp");
					rd.forward(request, response);
				}
			}
			}
		}
	}
