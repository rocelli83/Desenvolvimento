package action;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDAO;
import dao.ColaboradorDAO;
import dao.CursoDAO;
import dao.ExameDAO;
import dao.TurmasDeCursosDAO;
import model.Cliente;
import model.Colaborador;
import model.Curso;
import model.Exame;
import model.TurmasDeCurso;

public class ActionAlterar extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
				
		
		String cmdAlterar = request.getParameter("cmdAlterar");
		
		HttpSession session = request.getSession();
		
		
		
		
		if (cmdAlterar.equalsIgnoreCase("Cliente")) {
			
			String idCliente1 = request.getParameter("txtidCliente");
			int idCliente = Integer.parseInt(idCliente1);
			String nomeCliente = request.getParameter("txtnomeCliente");
			String cpfCnpjCliente1 = request.getParameter("txtcpfCnpjCliente");
			long cpfCnpjCliente = Long.parseLong(cpfCnpjCliente1);
			String emailCliente = request.getParameter("txtemailCliente");
			String rgCliente = request.getParameter("txtrgCliente");
			String dataNascCliente = request.getParameter("txtdataNascCliente");
			String endCliente = request.getParameter("txtendCliente");
			String telCliente = request.getParameter("txttelCliente");
			String celCliente = request.getParameter("txtcelCliente");
			String protocoloCliente = request.getParameter("txtprotocoloCliente");
			String dataCadastroCliente = request.getParameter("txtdataCadastroCliente");
			int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
			

			Cliente cliente = new Cliente();
			
			cliente.setIdCliente(idCliente);
			cliente.setNomeCliente(nomeCliente);
			cliente.setCpfCnpjCliente(cpfCnpjCliente);
			cliente.setEmailCliente(emailCliente);
			cliente.setRgCliente(rgCliente);
			cliente.setDataNascCliente(dataNascCliente);
			cliente.setEndCliente(endCliente);
			cliente.setTelCliente(telCliente);
			cliente.setCelCliente(celCliente);
			cliente.setProtocoloCliente(protocoloCliente);
			cliente.setDataCadastroCliente(dataCadastroCliente);
			cliente.setUsuario_idUsuario(usuario_idUsuario);

			ClienteDAO clientedao = new ClienteDAO();
			try {
				clientedao.alterar(cliente);

				RequestDispatcher rd = request.getRequestDispatcher("/successAlterar.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {

				e.printStackTrace();
			}
	}
		else if(cmdAlterar.equalsIgnoreCase("Colaborador")){
			
			
			
			String nomeColaborador = request.getParameter("txtnomeColaborador");
			String cpfColaborador1 = request.getParameter("txtcpfColaborador");
			long cpfColaborador = Long.parseLong(cpfColaborador1);
			String profissaoColaborador = request.getParameter("txtprofissaoColaborador");
			String telColaborador = request.getParameter("txttelColaborador");
			String emailColaborador = request.getParameter("txtemailColaborador");
			String enderecoColaborador = request.getParameter("txtenderecoColaborador");
			String registroColaborador = request.getParameter("txtregistroColaborador");
			int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
			String idColaborador1 = request.getParameter("txtidColaborador");
			int idColaborador = Integer.parseInt(idColaborador1);
			
			Colaborador colaborador = new Colaborador();
			
			colaborador.setIdColaborador(idColaborador);
			colaborador.setNomeColaborador(nomeColaborador);
			colaborador.setCpfColaborador(cpfColaborador);
			colaborador.setProfissaoColaborador(profissaoColaborador);
			colaborador.setTelColaborador(telColaborador);
			colaborador.setEmailColaborador(emailColaborador);
			colaborador.setEnderecoColaborador(enderecoColaborador);
			colaborador.setRegistroColaborador(registroColaborador);
			colaborador.setUsuario_idUsuario(usuario_idUsuario);
			
			ColaboradorDAO dao = new ColaboradorDAO();
			try {
				dao.alterar(colaborador);

				RequestDispatcher rd = request.getRequestDispatcher("/successAlterar.jsp");
				rd.forward(request, response);
				
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		else if(cmdAlterar.equalsIgnoreCase("curso")){
			
			String idCurso1 = request.getParameter("txtidCurso");
			int idCurso = Integer.parseInt(idCurso1);
			String nomeCurso = request.getParameter("txtnomeCurso");
			String categoriaCurso = request.getParameter("txtcategoriaCurso");
			String valorCurso1 = request.getParameter("txtvalorCurso");
			double valorCurso = Double.parseDouble(valorCurso1);
			int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
			
			Curso curso = new Curso();
			
			curso.setIdCurso(idCurso);
			curso.setNomeCurso(nomeCurso);
			curso.setCategoriaCurso(categoriaCurso);
			curso.setValorCurso(valorCurso);
			curso.setUsuario_idUsuario(usuario_idUsuario);
			
			CursoDAO dao = new CursoDAO();
			
			try {
				dao.alterar(curso);
				RequestDispatcher rd = request.getRequestDispatcher("/successAlterar.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(cmdAlterar.equalsIgnoreCase("Exame")){
			
			String nomeExame = request.getParameter("txtnomeExame");
			String idExame1 = request.getParameter("txtidExame");
			int idExame = Integer.parseInt(idExame1);	
			int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
			
			Exame exame = new Exame();
			
			exame.setIdExame(idExame);
			exame.setNomeExame(nomeExame);
			exame.setUsuario_idUsuario(usuario_idUsuario);
			
			ExameDAO dao = new ExameDAO();
			
			try {
				dao.alterar(exame);
				RequestDispatcher rd = request.getRequestDispatcher("/successAlterar.jsp");
				rd.forward(request, response);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	else if(cmdAlterar.equalsIgnoreCase("Turma")){
			
		String nomeTurma = request.getParameter("txtnomeTurma");
		String localTurma = request.getParameter("txtlocalTurma");
		String horarioTurma = request.getParameter("txthorarioTurma");
		String dataTurma = request.getParameter("txtdataTurma");
		String idTurma1 = request.getParameter("txtidTurma");
		int idTurma = Integer.parseInt(idTurma1);
		
		TurmasDeCurso turma = new TurmasDeCurso();

		turma.setNomeTurma(nomeTurma);
		turma.setLocalTurma(localTurma);
		turma.setHorarioTurma(horarioTurma);
		turma.setDataTurma(dataTurma);
		turma.setIdTurma(idTurma);
			
			TurmasDeCursosDAO dao = new TurmasDeCursosDAO();
			
			try {
				dao.alterar(turma);
				RequestDispatcher rd = request.getRequestDispatcher("/successAlterar.jsp");
				rd.forward(request, response);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
}
