package action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.ExameDAO;
import model.Exame;

public class ActionPesquisaExame extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String nomeExame = request.getParameter("txtnomeExame");
		String cmdPesquisar = request.getParameter("cmdPesquisar");

		if (cmdPesquisar.equalsIgnoreCase("Excluir")) {

			Exame exame = new Exame();

			ExameDAO examedao = new ExameDAO();

			exame.setNomeExame(nomeExame);

			ArrayList<Exame> listaExames = new ArrayList<Exame>();
			if (nomeExame.isEmpty()) {

				listaExames = examedao.retornaTodosExames();
				if (listaExames != null) {
					request.setAttribute("listaExames", listaExames);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirExame.jsp");
					rd.forward(request, response);

				}

			} else {
			listaExames = examedao.pesquisaExames(exame);

			if (listaExames != null) {
				request.setAttribute("listaExames", listaExames);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirExame.jsp");
				rd.forward(request, response);

			}

		}
		}
		else if (cmdPesquisar.equalsIgnoreCase("Alterar")) {
			Exame exame = new Exame();

			ExameDAO examedao = new ExameDAO();

			exame.setNomeExame(nomeExame);

			ArrayList<Exame> listaExames = new ArrayList<Exame>();
			if (nomeExame.isEmpty()) {

				listaExames = examedao.retornaTodosExames();
				if (listaExames != null) {
					request.setAttribute("listaExames", listaExames);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarExame.jsp");
					rd.forward(request, response);

				}

			} else {
			listaExames = examedao.pesquisaExames(exame);

			if (listaExames != null) {
				request.setAttribute("listaExames", listaExames);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarExame.jsp");
				rd.forward(request, response);

			}
		}} else if (cmdPesquisar.equalsIgnoreCase("Pesquisar")) {

			Exame exame = new Exame();

			ExameDAO examedao = new ExameDAO();

			exame.setNomeExame(nomeExame);

			ArrayList<Exame> listaExames = new ArrayList<Exame>();
			if (nomeExame.isEmpty()) {

				listaExames = examedao.retornaTodosExames();
				if (listaExames != null) {
					request.setAttribute("listaExames", listaExames);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExame.jsp");
					rd.forward(request, response);

				}

			} else {
			listaExames = examedao.pesquisaExames(exame);

			if (listaExames != null) {
				request.setAttribute("listaExames", listaExames);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExame.jsp");
				rd.forward(request, response);

			}

		}
	}

}}