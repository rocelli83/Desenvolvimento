package action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClienteDAO;

import model.Cliente;

public class ActionPesquisa extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String nomeCliente = request.getParameter("txtnomeCliente");
		String cmdPesquisar = request.getParameter("cmdPesquisar");

		if (cmdPesquisar.equalsIgnoreCase("Excluir")) {

			Cliente cliente = new Cliente();

			ClienteDAO clientedao = new ClienteDAO();

			cliente.setNomeCliente(nomeCliente);

			ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();
			if (nomeCliente.isEmpty()) {

				listaClientes = clientedao.retornaTodosClientes();
				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirCliente.jsp");
					rd.forward(request, response);

				}

			} else {
				listaClientes = clientedao.retornaPesquisa(cliente);

				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirCliente.jsp");
					rd.forward(request, response);

				}

			}
		} else if (cmdPesquisar.equalsIgnoreCase("Alterar")) {

			Cliente cliente = new Cliente();

			ClienteDAO clientedao = new ClienteDAO();

			cliente.setNomeCliente(nomeCliente);

			ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();
			if (nomeCliente.isEmpty()) {

				listaClientes = clientedao.retornaTodosClientes();
				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarCliente.jsp");
					rd.forward(request, response);

				}

			} else {
				listaClientes = clientedao.retornaPesquisa(cliente);

				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarCliente.jsp");
					rd.forward(request, response);

				}
			}
		} else if (cmdPesquisar.equalsIgnoreCase("Pesquisar")) {

			Cliente cliente = new Cliente();

			ClienteDAO clientedao = new ClienteDAO();

			cliente.setNomeCliente(nomeCliente);

			ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();
			if (nomeCliente.isEmpty()) {

				listaClientes = clientedao.retornaTodosClientes();
				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaCliente.jsp");
					rd.forward(request, response);

				}

			} else {
				listaClientes = clientedao.retornaPesquisa(cliente);

				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaCliente.jsp");
					rd.forward(request, response);

				}

			}
		} else if (cmdPesquisar.equalsIgnoreCase("turmaCliente")) {

			Cliente cliente = new Cliente();

			ClienteDAO clientedao = new ClienteDAO();

			cliente.setNomeCliente(nomeCliente);

			ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();

			if (nomeCliente != null) {

				listaClientes = clientedao.retornaPesquisa(cliente);

				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaCliente.jsp");
					rd.forward(request, response);

				}

			} else {
				listaClientes = clientedao.retornaTodosClientes();

				if (listaClientes != null) {
					request.setAttribute("listaClientes", listaClientes);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaCliente.jsp");
					rd.forward(request, response);

				}

			}
		}else if (cmdPesquisar.equalsIgnoreCase("imprimir")) {

			ClienteDAO dao = new ClienteDAO();
			ArrayList<Cliente> listaCliente = new ArrayList<Cliente>();
			
			listaCliente = dao.retornaTodosClientes();

			dao.imprimir(listaCliente);

			RequestDispatcher rd = request.getRequestDispatcher("/successAlterar.jsp");
			rd.forward(request, response);
		}
	}
}
