package action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDAO;
import dao.ColaboradorDAO;

import dao.ExameDAO;
import dao.MarcacaoExameDAO;

import model.Cliente;
import model.Colaborador;

import model.Exame;
import model.MarcacaoExame;


public class ActionMarcacao extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			HttpSession session = request.getSession();

			
			int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
			String exame_idExame1 = request.getParameter("txtExame_idExame");
			int exame_idExame = Integer.parseInt(exame_idExame1);
			String Colaborador_idColaborador1 = request.getParameter("txtColaborador_idColaborador");
			int colaborador_idColaborador = Integer.parseInt(Colaborador_idColaborador1);
			String Cliente_idCliente1 = request.getParameter("txtCliente_idCliente");
			int cliente_idCliente = Integer.parseInt(Cliente_idCliente1);
			String dataMarcacaoExame = request.getParameter("txtdataMarcacaoExame");
			String horarioMarcacao = request.getParameter("txthorarioMarcacao");
			String localMarcacaoExame = request.getParameter("txtlocalMarcacaoExame");
			
			MarcacaoExame marcacao = new MarcacaoExame();
			
			marcacao.setCliente_idCliente(cliente_idCliente);
			marcacao.setColaborador_idColaborador(colaborador_idColaborador);
			marcacao.setDataMarcacaoExame(dataMarcacaoExame);
			marcacao.setExame_idExame(exame_idExame);
			marcacao.setHorarioMarcacao(horarioMarcacao);
			marcacao.setLocalMarcacaoExame(localMarcacaoExame);
			marcacao.setUsuario_idUsuario(usuario_idUsuario);
			
			
			String cmdIncluir = request.getParameter("cmdCadastar");
			
			String cmdPesquisar = request.getParameter("cmdPesquisar");
			
		
			
			if (cmdIncluir != null) {
				MarcacaoExameDAO dao = new MarcacaoExameDAO();
				try {

					dao.incluir(marcacao);

					RequestDispatcher rd = request.getRequestDispatcher("/successCadastro.jsp");
					rd.forward(request, response);

				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		
			else if (cmdPesquisar.equalsIgnoreCase("marcacao") ) {


			

				ClienteDAO clientedao = new ClienteDAO();

				ColaboradorDAO colaboradorDAO = new ColaboradorDAO();

				ExameDAO examedao = new ExameDAO();

				ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();
				
				ArrayList<Colaborador> listaColaboradores = new ArrayList<Colaborador>();

				ArrayList<Exame> listaExames = new ArrayList<Exame>();
				
					listaClientes = clientedao.retornaTodosClientes();
					listaColaboradores = colaboradorDAO.retornaTodosColaboradores();
					listaExames = examedao.retornaTodosExames();
					
					if (listaClientes != null) {
						request.setAttribute("listaClientes", listaClientes);
						request.setAttribute("listaExames", listaExames);
						request.setAttribute("listaColaboradores", listaColaboradores);
						RequestDispatcher rd = request.getRequestDispatcher("/marcacao.jsp");
						rd.forward(request, response);
					}
				}
		

		}

	}
