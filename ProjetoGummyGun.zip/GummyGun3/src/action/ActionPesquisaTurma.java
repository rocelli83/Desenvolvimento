package action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.TurmasDeCursosDAO;
import model.TurmasDeCurso;

public class ActionPesquisaTurma extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String nomeTurma = request.getParameter("txtnomeTurma");

		String cmdPesquisar = request.getParameter("cmdPesquisar");

		if (cmdPesquisar.equalsIgnoreCase("Excluir")) {

			TurmasDeCurso turma = new TurmasDeCurso();

			TurmasDeCursosDAO turmadao = new TurmasDeCursosDAO();

			turma.setNomeTurma(nomeTurma);

			ArrayList<TurmasDeCurso> listaTurmas = new ArrayList<TurmasDeCurso>();

			if (nomeTurma.isEmpty()) {

				listaTurmas = turmadao.retornaTodasTurmas();
				if (listaTurmas != null) {
					request.setAttribute("listaTurmas", listaTurmas);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirTurma.jsp");
					rd.forward(request, response);

				}

			} else {

				listaTurmas = turmadao.pesquisaTurmas(turma);
				if (listaTurmas != null) {
					request.setAttribute("listaTurmas", listaTurmas);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirTurma.jsp");
					rd.forward(request, response);
				}

			}

		}

		else if (cmdPesquisar.equalsIgnoreCase("Alterar")) {

			TurmasDeCurso turma = new TurmasDeCurso();

			TurmasDeCursosDAO turmadao = new TurmasDeCursosDAO();

			turma.setNomeTurma(nomeTurma);

			ArrayList<TurmasDeCurso> listaTurmas = new ArrayList<TurmasDeCurso>();
			
			if (nomeTurma.isEmpty()) {

				listaTurmas = turmadao.retornaTodasTurmas();
				if (listaTurmas != null) {
					request.setAttribute("listaTurmas", listaTurmas);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarTurma.jsp");
					rd.forward(request, response);

				}
			}else {

					listaTurmas = turmadao.pesquisaTurmas(turma);
					if (listaTurmas != null) {
						request.setAttribute("listaTurmas", listaTurmas);
						RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarTurma.jsp");
						rd.forward(request, response);
					}

				}
		} 
		else if (cmdPesquisar.equalsIgnoreCase("Pesquisar")) {

			TurmasDeCurso turma = new TurmasDeCurso();

			TurmasDeCursosDAO turmadao = new TurmasDeCursosDAO();

			turma.setNomeTurma(nomeTurma);

			ArrayList<TurmasDeCurso> listaTurmas = new ArrayList<TurmasDeCurso>();
			if (nomeTurma.isEmpty()) {

				listaTurmas = turmadao.retornaTodasTurmas();
				if (listaTurmas != null) {
					request.setAttribute("listaTurmas", listaTurmas);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaTurma.jsp");
					rd.forward(request, response);

				}

			} else {

				listaTurmas = turmadao.pesquisaTurmas(turma);
				if (listaTurmas != null) {
					request.setAttribute("listaTurmas", listaTurmas);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaTurma.jsp");
					rd.forward(request, response);
				}

			}
		}

	}

}