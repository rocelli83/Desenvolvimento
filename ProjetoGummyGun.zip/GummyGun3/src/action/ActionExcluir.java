package action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.ClienteDAO;
import dao.ColaboradorDAO;
import dao.CursoDAO;
import dao.ExameDAO;
import dao.TurmasDeCursosDAO;
import model.Cliente;
import model.Colaborador;
import model.Curso;
import model.Exame;
import model.TurmasDeCurso;

public class ActionExcluir extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String cmdExcluir = request.getParameter("cmdExcluir");

		if (cmdExcluir.equalsIgnoreCase("Cliente")) {

			String idCliente1 = request.getParameter("txtidCliente");
			int idCliente = Integer.parseInt(idCliente1);
			Cliente cliente = new Cliente();

			cliente.setIdCliente(idCliente);

			ClienteDAO clientedao = new ClienteDAO();

			try {
				clientedao.deletar(cliente);

				RequestDispatcher rd = request.getRequestDispatcher("/successExcluir.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		} else if (cmdExcluir.equalsIgnoreCase("Colaborador")) {

			String idColaborador1 = request.getParameter("txtidColaborador");
			int idColaborador = Integer.parseInt(idColaborador1);
			
			Colaborador colaborador = new Colaborador();

			colaborador.setIdColaborador(idColaborador);

			ColaboradorDAO colaboradordao = new ColaboradorDAO();

			try {
				colaboradordao.deletar(colaborador);

				RequestDispatcher rd = request.getRequestDispatcher("/successExcluir.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		else if (cmdExcluir.equalsIgnoreCase("Exame")) {

			String idExame1 = request.getParameter("txtidExame");
			int idExame = Integer.parseInt(idExame1);
			
			Exame exame = new Exame();

			exame.setIdExame(idExame);

			ExameDAO examedao = new ExameDAO();

			try {
				examedao.deletar(exame);

				RequestDispatcher rd = request.getRequestDispatcher("/successExcluir.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		else if (cmdExcluir.equalsIgnoreCase("Curso")) {

			String idCurso1 = request.getParameter("txtidCurso");
			int idCurso = Integer.parseInt(idCurso1);
			
			Curso curso = new Curso();

			curso.setIdCurso(idCurso);

			CursoDAO cursoDAO = new CursoDAO();

			try {
				cursoDAO.deletar(curso);

				RequestDispatcher rd = request.getRequestDispatcher("/successExcluir.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		else if (cmdExcluir.equalsIgnoreCase("Turma")) {

			String idTurma1 = request.getParameter("txtidTurma");
			int idTurma = Integer.parseInt(idTurma1);
			
			TurmasDeCurso turma = new TurmasDeCurso();

			turma.setIdTurma(idTurma);

			TurmasDeCursosDAO turmadao = new TurmasDeCursosDAO();

			try {
				turmadao.deletar(turma);

				RequestDispatcher rd = request.getRequestDispatcher("/successExcluir.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}else if (cmdExcluir.equalsIgnoreCase("imprimir")) {

			ClienteDAO dao = new ClienteDAO();
			ArrayList<Cliente> listaCliente = new ArrayList<Cliente>();
			
			listaCliente = dao.retornaTodosClientes();

			dao.imprimir(listaCliente);

			RequestDispatcher rd = request.getRequestDispatcher("/successAlterar.jsp");
			rd.forward(request, response);
		}
	}
}


