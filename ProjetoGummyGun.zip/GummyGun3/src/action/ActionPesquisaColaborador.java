package action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao.ColaboradorDAO;
import model.Colaborador;


public class ActionPesquisaColaborador extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String nomeColaborador = request.getParameter("txtnomeColaborador");
		String cmdPesquisar = request.getParameter("cmdPesquisar");

		if (cmdPesquisar.equalsIgnoreCase("Excluir")) {

			Colaborador colaborador = new Colaborador();

			ColaboradorDAO colaboradordao = new ColaboradorDAO();

			colaborador.setNomeColaborador(nomeColaborador);

			ArrayList<Colaborador> listaColaboradores = new ArrayList<Colaborador>();
			if (nomeColaborador.isEmpty()) {

				listaColaboradores = colaboradordao.retornaTodosColaboradores();
				if (listaColaboradores != null) {
					request.setAttribute("listaColaboradores", listaColaboradores);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirColaborador.jsp");
					rd.forward(request, response);

				}

			} else {
			listaColaboradores = colaboradordao.pesquisaColaboradores(colaborador);

			if (listaColaboradores != null) {
				request.setAttribute("listaColaboradores", listaColaboradores);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaExcluirColaborador.jsp");
				rd.forward(request, response);

			}

		}
		}
		else if (cmdPesquisar.equalsIgnoreCase("Alterar")) {

			Colaborador colaborador = new Colaborador();

			ColaboradorDAO colaboradordao = new ColaboradorDAO();

			colaborador.setNomeColaborador(nomeColaborador);
			

			ArrayList<Colaborador> listaColaboradores = new ArrayList<Colaborador>();
			if (nomeColaborador.isEmpty()) {

				listaColaboradores = colaboradordao.retornaTodosColaboradores();
				if (listaColaboradores != null) {
					request.setAttribute("listaColaboradores", listaColaboradores);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarColaborador.jsp");
					rd.forward(request, response);

				}

			} else {
			listaColaboradores = colaboradordao.pesquisaColaboradores(colaborador);

			if (listaColaboradores != null) {
				request.setAttribute("listaColaboradores", listaColaboradores);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaAlterarColaborador.jsp");
				rd.forward(request, response);

			}
		} }else if (cmdPesquisar.equalsIgnoreCase("Pesquisar")) {

			Colaborador colaborador = new Colaborador();

			ColaboradorDAO colaboradordao = new ColaboradorDAO();

			colaborador.setNomeColaborador(nomeColaborador);

			ArrayList<Colaborador> listaColaboradores = new ArrayList<Colaborador>();
			if (nomeColaborador.isEmpty()) {

				listaColaboradores = colaboradordao.retornaTodosColaboradores();
				if (listaColaboradores != null) {
					request.setAttribute("listaColaboradores", listaColaboradores);
					RequestDispatcher rd = request.getRequestDispatcher("/pesquisaColaborador.jsp");
					rd.forward(request, response);

				}

			} else {
			listaColaboradores = colaboradordao.pesquisaColaboradores(colaborador);

			if (listaColaboradores != null) {
				request.setAttribute("listaColaboradores", listaColaboradores);
				RequestDispatcher rd = request.getRequestDispatcher("/pesquisaColaborador.jsp");
				rd.forward(request, response);

			}

			}}
		else if (cmdPesquisar.equalsIgnoreCase("turmacolaborador")) {

			Colaborador colaborador = new Colaborador();

			ColaboradorDAO colaboradordao = new ColaboradorDAO();

			colaborador.setNomeColaborador(nomeColaborador);

			ArrayList<Colaborador> listaColaboradores = new ArrayList<Colaborador>();

			
			if (nomeColaborador != null) {
				
				listaColaboradores = colaboradordao.pesquisaColaboradores(colaborador);

				if (listaColaboradores != null) {
					request.setAttribute("listaColaboradores", listaColaboradores);
					RequestDispatcher rd = request.getRequestDispatcher("/turmas.jsp");
					rd.forward(request, response);

				}

			} else {
				
				listaColaboradores = colaboradordao.retornaTodosColaboradores();
			
			if (listaColaboradores != null) {
				request.setAttribute("listaColaboradores", listaColaboradores);
				RequestDispatcher rd = request.getRequestDispatcher("/turmas.jsp");
				rd.forward(request, response);
			}
		}

		}
	}

}
