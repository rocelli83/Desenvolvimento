package action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClienteDAO;

import dao.Turma_ClienteDAO;
import dao.TurmasDeCursosDAO;
import model.Cliente;

import model.Turma_Cliente;
import model.TurmasDeCurso;

public class ActionTurmaCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String cmdIncluir = request.getParameter("cmdIncluir");
		String cmdPesquisar = request.getParameter("cmdPesquisar");

		
		

		if (cmdIncluir != null) {
			
			String cliente_idCliente1 = request.getParameter("txtCliente_idCliente");
			int cliente_idCliente = Integer.parseInt(cliente_idCliente1);
			String turma_idTurma1 = request.getParameter("txtTurma_idTurma");
			int turma_idTurma = Integer.parseInt(turma_idTurma1);

			Turma_Cliente turma = new Turma_Cliente();

			
			turma.setTurma_idTurma(turma_idTurma);
			turma.setCliente_idCliente(cliente_idCliente);
			Turma_ClienteDAO dao = new Turma_ClienteDAO();
			
			try {
				dao.incluir(turma);
				RequestDispatcher rd = request.getRequestDispatcher("/successAluno.jsp");
				rd.forward(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (cmdPesquisar.equalsIgnoreCase("turmacurso")) {

		
			ClienteDAO clientedao = new ClienteDAO();

			TurmasDeCursosDAO turmaCursodao = new TurmasDeCursosDAO();

			ArrayList<TurmasDeCurso> listaTurma = new ArrayList<TurmasDeCurso>();

			ArrayList<Cliente> listaCliente = new ArrayList<Cliente>();

			listaCliente = clientedao.retornaTodosClientes();
			listaTurma = turmaCursodao.retornaTodasTurmas();

			if (listaCliente != null) {
				
				
				request.setAttribute("listaCliente", listaCliente);

				request.setAttribute("listaTurma", listaTurma);
				RequestDispatcher rd = request.getRequestDispatcher("/cadastraTurmaCliente.jsp");
				rd.forward(request, response);
			}
		} else if (cmdPesquisar.equalsIgnoreCase("exibir")) {
			String turma_idTurma1 = request.getParameter("txtTurma_idTurma");
			int turma_idTurma = Integer.parseInt(turma_idTurma1);

			Turma_Cliente turma = new Turma_Cliente();

			
			turma.setTurma_idTurma(turma_idTurma);
			Turma_ClienteDAO turmadao = new Turma_ClienteDAO();
			ArrayList<Cliente> listaCliente = new ArrayList<Cliente>();
			listaCliente = turmadao.retornaPesquisa(turma);
			
			if (listaCliente != null) {
				request.setAttribute("listaCliente", listaCliente);

				request.setAttribute("TurmaID", turma_idTurma);
				RequestDispatcher rd = request.getRequestDispatcher("/alterarTurmaCliente.jsp");
				rd.forward(request, response);
			}
		}
	else if (cmdPesquisar.equalsIgnoreCase("excluir")) {

		String cliente_idCliente1 = request.getParameter("txtCliente_idCliente");
		int cliente_idCliente = Integer.parseInt(cliente_idCliente1);
		String turma_idTurma1 = request.getParameter("txtTurma_idturma");
		int turma_idTurma = Integer.parseInt(turma_idTurma1);

		Turma_Cliente turma = new Turma_Cliente();

		
		turma.setTurma_idTurma(turma_idTurma);
		
		Turma_ClienteDAO turmadao = new Turma_ClienteDAO();
		turma.setCliente_idCliente(cliente_idCliente);
		
		
		try {
			turmadao.deletar(turma);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			RequestDispatcher rd = request.getRequestDispatcher("/alterarTurmaCliente.jsp");
			rd.forward(request, response);
		}
	else if (cmdPesquisar.equalsIgnoreCase("pesquisar")) {
		
		TurmasDeCursosDAO turmaCursodao = new TurmasDeCursosDAO();

		ArrayList<TurmasDeCurso> listaTurma = new ArrayList<TurmasDeCurso>();

		listaTurma = turmaCursodao.retornaTodasTurmas();

		if (listaTurma != null) {
			
			request.setAttribute("listaTurma", listaTurma);
			
			RequestDispatcher rd = request.getRequestDispatcher("/alterarTurmaCliente.jsp");
			rd.forward(request, response);
		}
}
	}
}

