package action;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.RegistroArmaDAO;
import model.RegistroArma;


public class ActionArma extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();

		String nomeArma = request.getParameter("txtnomeArma");
		int usuario_idUsuario = (int) session.getAttribute("txtidUsuario");
		String registroArma = request.getParameter("txtregistroArma");
		String cliente_idCliente1 = request.getParameter("txtcliente_idCliente");
		int cliente_idCliente = Integer.parseInt(cliente_idCliente1);
		String validadeSinarm = request.getParameter("txtvalidadeSinarm");
		String cadastroSinarm = request.getParameter("txtcadastroSinarm");
		String calibreArma1 = request.getParameter("txtcalibreArma");
		int calibreArma = Integer.parseInt(calibreArma1);
		String tirosArma1 = request.getParameter("txttirosArma");
		int tirosArma = Integer.parseInt(tirosArma1);
		String funcionamentoArma = request.getParameter("txtfuncionamentoArma");
		String paisFabArma = request.getParameter("txtpaisFabArma");
		String nfArma = request.getParameter("txtnfArma");
		String datanfArma = request.getParameter("txtdatanfArma");
		String validadeCRAF = request.getParameter("txtvalidadeCRAF");
		String expedicaoArma = request.getParameter("txtexpedicaoArma");
		String serieArma = request.getParameter("txtserieArma");
		String sigmaArma1 = request.getParameter("txtsigmaArma");
		int sigmaArma = Integer.parseInt(sigmaArma1);
		String tipoRegistro = request.getParameter("txttipoRegistro");
		String obsArma = request.getParameter("txtobsArma");
		
		String cmdIncluir = request.getParameter("cmdCadastar");
		
		RegistroArma registro = new RegistroArma();
		
		registro.setNomeArma(nomeArma);
		registro.setCliente_idCliente(cliente_idCliente);
		registro.setCadastroSinarm(cadastroSinarm);
		registro.setCalibreArma(calibreArma);
		registro.setDatanfArma(datanfArma);
		registro.setExpedicaoArma(expedicaoArma);
		registro.setFuncionamentoArma(funcionamentoArma);
		registro.setNfArma(nfArma);
		registro.setObsArma(obsArma);
		registro.setPaisFabArma(paisFabArma);
		registro.setRegistroArma(registroArma);
		registro.setSerieArma(serieArma);
		registro.setSigmaArma(sigmaArma);
		registro.setTipoRegistro(tipoRegistro);
		registro.setTirosArma(tirosArma);
		registro.setValidadeCRAF(validadeCRAF);
		registro.setValidadeSinarm(validadeSinarm);
		registro.setUsuario_idUsuario(usuario_idUsuario);
		
		RegistroArmaDAO dao = new RegistroArmaDAO();
		
		if (cmdIncluir.equalsIgnoreCase("Cadastrar")) {

			try {

				dao.incluir(registro);

				RequestDispatcher rd = request.getRequestDispatcher("/successCadastro.jsp");
				rd.forward(request, response);

			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		
		
	}
}
