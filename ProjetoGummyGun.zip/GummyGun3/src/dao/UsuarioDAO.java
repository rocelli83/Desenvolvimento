package dao;

import java.sql.*;
import java.util.*;

import model.Usuario;
import dao.Conexao;

public class UsuarioDAO {

	private Connection con;

	public UsuarioDAO() {
		new Conexao();
		this.con = Conexao.obterConexao();
	}

	private static final String inserir = "INSERT INTO usuario (loginUsuario, senhaUsuario, emailUsuario, acessoUsuario) values (?,?,?,?)";
	private static final String update = "UPDATE usuario SET senhaUsuario = ? WHERE loginUsuario = ?";
	private static final String delete = "DELETE FROM usuario WHERE loginUsuario = ?";
	private static final String consulta = "SELECT * FROM usuario WHERE loginUsuario = ? AND senhaUsuario = ?";

	public void incluir(Usuario usuario) throws SQLException {
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		pstmt.setString(1, usuario.getLoginUsuario());
		pstmt.setString(2, usuario.getSenhaUsuario());
		pstmt.setString(3, usuario.getEmailUsuario());
		pstmt.setInt(4, usuario.getAcessoUsuario());
		pstmt.execute();

	}

	public void update(Usuario usuario) throws SQLException {
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);
		pstmt.setString(1, usuario.getSenhaUsuario());
		pstmt.setString(2, usuario.getLoginUsuario());
		pstmt.setString(3, usuario.getEmailUsuario());
		pstmt.setInt(4, usuario.getAcessoUsuario());
		pstmt.execute();
	}

	public void delete(Usuario usuario) throws SQLException {
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setString(1, usuario.getLoginUsuario());
		pstmt.execute();
	}

	public void consulta(Usuario usuario) throws SQLException {
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(consulta);
		pstmt.setString(1, usuario.getLoginUsuario());
		pstmt.setString(2, usuario.getSenhaUsuario());
		pstmt.execute();
	}

	public ArrayList<Usuario> retornaTodosUsuarios() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM usuario");

		ArrayList<Usuario> listaUsuarios = new ArrayList<Usuario>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				Usuario usuario = new Usuario();
				usuario.setIdUsuario(rs.getInt("idUsuario"));
				usuario.setLoginUsuario(rs.getString("loginUsuario"));
				usuario.setSenhaUsuario(rs.getString("senhaUsuario"));
				listaUsuarios.add(usuario);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaUsuarios;
	}

	public boolean retornaUmUsuario(Usuario usuario) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM usuario WHERE loginUsuario = '");
		sql.append(usuario.getLoginUsuario() + "'");
		sql.append("and senhaUsuario = '");
		sql.append(usuario.getSenhaUsuario() + "'");
		
		Usuario user = new Usuario();
		
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()){ 
			user.setLoginUsuario(rs.getString("loginUsuario"));
			user.setSenhaUsuario(rs.getString("senhaUsuario"));
			}
			
			
			if (user != null)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}
	public Usuario dadosUsuario(Usuario usuario) {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM usuario WHERE loginUsuario = '");
		sql.append(usuario.getLoginUsuario() + "'");
		sql.append("and senhaUsuario = '");
		sql.append(usuario.getSenhaUsuario() + "'");
		
		Usuario user = new Usuario();
		
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()){ 
			user.setLoginUsuario(rs.getString("loginUsuario"));
			user.setSenhaUsuario(rs.getString("senhaUsuario"));
			user.setIdUsuario(rs.getInt("idUsuario"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}
}
