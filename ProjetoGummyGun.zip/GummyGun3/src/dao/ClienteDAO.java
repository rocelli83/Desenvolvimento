package dao;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.sql.*;
import java.util.ArrayList;

import model.Cliente;

public class ClienteDAO {

	private Connection con;

	public ClienteDAO() {
		new Conexao();
		this.con = Conexao.obterConexao();
	}

	private static final String inserir = "INSERT INTO cliente (nomeCliente, cpfCnpjCliente, emailCliente, rgCliente, "
			+ "dataNascCliente, endCliente, telCliente, protocoloCliente, dataCadastroCliente, celCliente, Usuario_idUsuario) "
			+ "values (?,?,?,?,?,?,?,?,?,?,?)";
	private static final String delete = "DELETE FROM cliente WHERE idCliente = ?";
	private static final String update = "UPDATE cliente SET nomeCliente = ?, cpfCnpjCliente = ?, emailCliente = ?, rgCliente = ?, "
			+ "dataNascCliente = ?, endCliente = ?, telCliente = ?, protocoloCliente = ?, dataCadastroCliente = ?, celCliente = ? WHERE idCliente = ?";

	private static final String consulta = "SELECT * FROM cliente WHERE nomeCliente = ? or cpfCnpjCliente = ?";

	public void incluir(Cliente cliente) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		pstmt.setString(1, cliente.getNomeCliente());
		pstmt.setLong(2, cliente.getCpfCnpjCliente());
		pstmt.setString(3, cliente.getEmailCliente());
		pstmt.setString(4, cliente.getRgCliente());
		pstmt.setString(5, cliente.getDataNascCliente());
		pstmt.setString(6, cliente.getEndCliente());
		pstmt.setString(7, cliente.getTelCliente());
		pstmt.setString(8, cliente.getProtocoloCliente());
		pstmt.setString(9, cliente.getDataCadastroCliente());
		pstmt.setString(10, cliente.getCelCliente());
		pstmt.setInt(11, cliente.getUsuario_idUsuario());
		pstmt.execute();
		pstmt.close();

	}

	public void deletar(Cliente cliente) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setInt(1, cliente.getIdCliente());
		pstmt.execute();
		pstmt.close();
	}

	public void alterar(Cliente cliente) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);
		pstmt.setString(1, cliente.getNomeCliente());
		pstmt.setLong(2, cliente.getCpfCnpjCliente());
		pstmt.setString(3, cliente.getEmailCliente());
		pstmt.setString(4, cliente.getRgCliente());
		pstmt.setString(5, cliente.getDataNascCliente());
		pstmt.setString(6, cliente.getEndCliente());
		pstmt.setString(7, cliente.getTelCliente());
		pstmt.setString(8, cliente.getProtocoloCliente());
		pstmt.setString(9, cliente.getDataCadastroCliente());
		pstmt.setString(10, cliente.getCelCliente());
		pstmt.setInt(11, cliente.getIdCliente());
		pstmt.execute();
		pstmt.close();
	}

	public void consultar(Cliente cliente) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(consulta);
		pstmt.setString(1, cliente.getNomeCliente());
		pstmt.setLong(2, cliente.getCpfCnpjCliente());
		pstmt.execute();
		pstmt.close();
	}

	public ArrayList<Cliente> retornaTodosClientes() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM cliente");

		ArrayList<Cliente> listaDeClientes = new ArrayList<Cliente>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				Cliente cliente = new Cliente();
				cliente.setIdCliente(rs.getInt("idCliente"));
				cliente.setNomeCliente(rs.getString("nomeCliente"));
				cliente.setCpfCnpjCliente(rs.getLong("cpfCnpjCliente"));
				cliente.setEmailCliente(rs.getString("emailCliente"));
				cliente.setRgCliente(rs.getString("rgCliente"));
				cliente.setDataNascCliente(rs.getString("dataNascCliente"));
				cliente.setEndCliente(rs.getString("endCliente"));
				cliente.setTelCliente(rs.getString("telCliente"));
				cliente.setProtocoloCliente(rs.getString("protocoloCliente"));
				cliente.setDataCadastroCliente(rs.getString("dataCadastroCliente"));
				cliente.setCelCliente(rs.getString("celCliente"));
				listaDeClientes.add(cliente);
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaDeClientes;
	}
	
	
	public ArrayList<Cliente> retornaPesquisa(Cliente cliente) {
		StringBuilder sql = new StringBuilder();

		sql.append("select * from cliente where nomeCliente like'%");
		sql.append(cliente.getNomeCliente()+"%'");

				
		ArrayList<Cliente> listarClientes = new ArrayList<Cliente>();
		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				Cliente cliente1 = new Cliente();
				cliente1.setIdCliente(rs.getInt("idCliente"));
				cliente1.setNomeCliente(rs.getString("nomeCliente"));
				cliente1.setCpfCnpjCliente(rs.getLong("cpfCnpjCliente"));
				cliente1.setEmailCliente(rs.getString("emailCliente"));
				cliente1.setRgCliente(rs.getString("rgCliente"));
				cliente1.setDataNascCliente(rs.getString("dataNascCliente"));
				cliente1.setEndCliente(rs.getString("endCliente"));
				cliente1.setTelCliente(rs.getString("telCliente"));
				cliente1.setProtocoloCliente(rs.getString("protocoloCliente"));
				cliente1.setDataCadastroCliente(rs.getString("dataCadastroCliente"));
				cliente1.setCelCliente(rs.getString("celCliente"));
				listarClientes.add(cliente1);
				
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listarClientes;
	}
	
	public void imprimir(ArrayList<Cliente> listaClientes) {
		// cria um frame tempor�rio, onde ser� desenhado o texto a ser impresso
		Frame f = new Frame( "Frame tempor�rio" );
		f.pack();
		// pega o Toolkit do Frame
		Toolkit tk = f.getToolkit();
		// Pega os servi�os de impress�o existentes no computador,
		// para que seja escolhida uma impressora.
		// Tamb�m pode ser uma impressora de rede
		PrintJob pj = tk.getPrintJob(f, "print" , null);
		// Aqui inicia-se a impressao
		if (pj != null) {
		Graphics g = pj.getGraphics();
		g.drawString( "Relacao de clientes" , 50, 30);
		int y = 70;
		for(int i = 0; i < listaClientes.size(); i++) {
		Cliente c = (Cliente)listaClientes.get(i);
		g.drawString( "Cadastro:" + c.getIdCliente(), 50, y);
		 y += 25;
		 g.drawString(" Nome: "+ c.getNomeCliente() , 50, y);
		  y+= 25;
		 g.drawString( "Email: " + c.getEmailCliente(), 50, y);
		  y+= 25;
		 g.drawString( "Telefone:" + c.getTelCliente(), 50, y);
		  y+= 50;
		 }
		 // libera os recursos gr�ficos
		 g.dispose();
		 // encerra a impress�o
		 pj.end();
		 }
		 // desfaz o frame tempor�rio
		 f.dispose();
		 }
	
		
}
