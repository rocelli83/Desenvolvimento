package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Curso;
import model.Exame;

public class ExameDAO {
	
		private Connection con;

		public ExameDAO() {
			new Conexao();
			this.con = Conexao.obterConexao();
		}
		
		private static final String inserir = "INSERT INTO exame (nomeExame, Usuario_idUsuario) "
				+ "values (?,?)";
		private static final String delete = "DELETE FROM exame WHERE idExame = ?";
		private static final String update = "UPDATE exame SET nomeExame = ? WHERE idExame = ?";
		
		public void incluir(Exame exame) throws SQLException{
			
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
			pstmt.setString(1, exame.getNomeExame());
			pstmt.setInt(2, exame.getUsuario_idUsuario());
			pstmt.execute();
		}
		public void deletar(Exame exame) throws SQLException{
			
			PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
			pstmt.setInt(1, exame.getIdExame());
			pstmt.execute();
		}
		public void alterar(Exame exame) throws SQLException{
			PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);
			pstmt.setString(1, exame.getNomeExame());
			pstmt.setInt(2, exame.getIdExame());
			pstmt.execute();
		}
		
		public ArrayList<Exame> retornaTodosExames() {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT * FROM exame");

			ArrayList<Exame> listaDeExames = new ArrayList<Exame>();

			try {
				Connection con = Conexao.obterConexao();
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(sql.toString());
				while (rs.next()) {
					Exame exame = new Exame();
					exame.setIdExame(rs.getInt("idExame"));
					exame.setNomeExame(rs.getString("nomeExame"));
					exame.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
					
					listaDeExames.add(exame);
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}

			return listaDeExames;
			
		}
			public ArrayList<Exame> pesquisaExames(Exame exame) {
				StringBuilder sql = new StringBuilder();
				
				sql.append("SELECT * FROM exame where nomeExame like'%");
				sql.append(exame.getNomeExame()+"%'");
				
				ArrayList<Exame> listarExames = new ArrayList<Exame>();

				try {
					Connection con = Conexao.obterConexao();
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery(sql.toString());
					while (rs.next()) {
						
						Exame exame1 = new Exame();
						exame1.setIdExame(rs.getInt("idExame"));
						exame1.setNomeExame(rs.getString("nomeExame"));
						exame1.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
						
						listarExames.add(exame1);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				}

				return listarExames;
			}
}