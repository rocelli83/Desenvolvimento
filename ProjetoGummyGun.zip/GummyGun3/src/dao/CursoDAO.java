package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Colaborador;
import model.Curso;

public class CursoDAO {
	private Connection con;

	public CursoDAO() {
		new Conexao();
		this.con = Conexao.obterConexao();
	}

	private static final String inserir = "INSERT INTO curso (nomeCurso, categoriaCurso, valorCurso, Usuario_idUsuario)"
			+ "values (?,?,?,?)";
	private static final String delete = "DELETE FROM curso WHERE idCurso = ?";
	private static final String update = "UPDATE curso SET nomeCurso = ?, categoriaCurso = ?, valorCurso = ? WHERE idCurso = ?";

	public void incluir(Curso curso) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		pstmt.setString(1, curso.getNomeCurso());
		pstmt.setString(2, curso.getCategoriaCurso());
		pstmt.setDouble(3, curso.getValorCurso());
		pstmt.setInt(4, curso.getUsuario_idUsuario());
		pstmt.execute();
	}

	public void deletar(Curso curso) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setInt(1, curso.getIdCurso());
		pstmt.execute();
	}

	public void alterar(Curso curso) throws SQLException {
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);
		pstmt.setString(1, curso.getNomeCurso());
		pstmt.setString(2, curso.getCategoriaCurso());
		pstmt.setDouble(3, curso.getValorCurso());
		pstmt.setInt(4, curso.getIdCurso());
		pstmt.execute();
	}

	public ArrayList<Curso> retornaTodosCursos() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM curso");

		ArrayList<Curso> listaDeCursos = new ArrayList<Curso>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				Curso curso = new Curso();
				curso.setIdCurso(rs.getInt("idCurso"));
				curso.setNomeCurso(rs.getString("nomeCurso"));
				curso.setCategoriaCurso(rs.getString("categoriaCurso"));
				curso.setValorCurso(rs.getDouble("valorCurso"));
				curso.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));

				listaDeCursos.add(curso);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaDeCursos;
	}
	
	public ArrayList<Curso> pesquisaCursos(Curso curso) {
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM curso where nomeCurso like'%");
		sql.append(curso.getNomeCurso()+"%'");
		
		ArrayList<Curso> listarCursos = new ArrayList<Curso>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				
				Curso curso1 = new Curso();
				
				curso1.setIdCurso(rs.getInt("idCurso"));
				curso1.setNomeCurso(rs.getString("nomeCurso"));
				curso1.setCategoriaCurso(rs.getString("categoriaCurso"));
				curso1.setValorCurso(rs.getDouble("valorCurso"));
				curso1.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
				
				listarCursos.add(curso1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listarCursos;
	}
}
