package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Cliente;
import model.Turma_Cliente;
import model.TurmasDeCurso;



public class Turma_ClienteDAO {
	private Connection con;
	
	public Turma_ClienteDAO(){
		new Conexao();
		this.con = Conexao.obterConexao();
	}
	private static final String inserir = "INSERT INTO turma_cliente (Cliente_idCliente, Turma_idTurma) "
			+ "values (?,?)";
	private static final String delete = "DELETE FROM turma_cliente WHERE Cliente_idCliente = ? and Turma_idTurma = ?";
	private static final String update = "UPDATE turmasdecurso SET "
			+ "localTurma = ?, horarioTurma = ?, dataTurma = ?, nomeTurma = ? WHERE idTurma = ?";
	
	public void incluir(Turma_Cliente turmas) throws SQLException{
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		pstmt.setInt(1, turmas.getCliente_idCliente());
		pstmt.setInt(2, turmas.getTurma_idTurma());
		pstmt.execute();
	}
	
	public void deletar(Turma_Cliente turma) throws SQLException{
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setInt(1, turma.getCliente_idCliente());
		pstmt.setInt(2, turma.getTurma_idTurma());
		pstmt.execute();
	}
	
		public ArrayList<Cliente> retornaPesquisa(Turma_Cliente turma) {
			StringBuilder sql = new StringBuilder();
			sql.append("select * from turma_cliente inner join turmasdecurso on turma_cliente.Turma_idTurma = "
					+ "turmasdecurso.idTurma inner join cliente on turma_cliente.Cliente_idCliente = cliente.idCliente where idTurma=");
			sql.append(turma.getTurma_idTurma()+";");

			ArrayList<Cliente> listaDeClientes = new ArrayList<Cliente>();

			try {
				Connection con = Conexao.obterConexao();
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(sql.toString());
				while (rs.next()) {
					Cliente cliente = new Cliente();
					cliente.setIdCliente(rs.getInt("idCliente"));
					cliente.setNomeCliente(rs.getString("nomeCliente"));
					cliente.setEmailCliente(rs.getString("emailCliente"));
					cliente.setTelCliente(rs.getString("telCliente"));
					cliente.setCelCliente(rs.getString("celCliente"));
					listaDeClientes.add(cliente);
				}
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			return listaDeClientes;
		}

}
	
	

