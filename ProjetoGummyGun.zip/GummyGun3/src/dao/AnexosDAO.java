package dao;

import java.sql.*;

public class AnexosDAO {

	private Connection con;

	public AnexosDAO() {
		new Conexao();
		this.con = Conexao.obterConexao();
	}
	/*private static final String inserir = "INSERT INTO cliente (nomeCliente, cpfCnpjCliente, emailCliente, rgCliente, "
			+ "dataNascCliente, endCliente, telCliente, protocoloCliente, dataCadastroCliente, celCliente, Usuario_idUsuario) "
			+ "values (?,?,?,?,?,?,?,?,?,?,?)";*/
}
