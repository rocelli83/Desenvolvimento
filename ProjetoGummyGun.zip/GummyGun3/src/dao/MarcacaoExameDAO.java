package dao;

import java.sql.*;
import java.util.ArrayList;

import model.MarcacaoExame;

public class MarcacaoExameDAO {
	private Connection con;

	public MarcacaoExameDAO() {

		new Conexao();
		this.con = Conexao.obterConexao();
	}

	private static final String inserir = "INSERT INTO marcacaoexame (Exame_idExame, Usuario_idUsuario, Colaborador_idColaborador,"
			+ " Cliente_idCliente, dataMarcacaoExame, horarioMarcacao, localMarcacaoExame)" + "values (?,?,?,?,?,?,?)";
	private static final String delete = "DELETE FROM marcacaoexame WHERE Exame_idExame = ? AND Cliente_idCliente = ?";
	private static final String update = "UPDATE marcacaoexame SET Exame_idExame= ?, Colaborador_idColaborador = ?, Cliente_idCliente = ?,"
			+ "dataMarcacaoExame = ?, horarioMarcacao = ?, localMarcacaoExame = ? WHERE idMarcacaoExame = ?";

	public void incluir(MarcacaoExame marcacao) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		pstmt.setInt(1, marcacao.getExame_idExame());
		pstmt.setInt(2, marcacao.getUsuario_idUsuario());
		pstmt.setInt(3, marcacao.getColaborador_idColaborador());
		pstmt.setInt(4, marcacao.getCliente_idCliente());
		pstmt.setString(5, marcacao.getDataMarcacaoExame());
		pstmt.setString(6, marcacao.getHorarioMarcacao());
		pstmt.setString(7, marcacao.getLocalMarcacaoExame());
		pstmt.execute();
	}

	public void deletar(MarcacaoExame marcacao) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setInt(1, marcacao.getExame_idExame());
		pstmt.setInt(2, marcacao.getCliente_idCliente());
		pstmt.execute();
	}

	public void alterar(MarcacaoExame marcacao) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);

		pstmt.setInt(1, marcacao.getExame_idExame());
		pstmt.setInt(2, marcacao.getColaborador_idColaborador());
		pstmt.setInt(3, marcacao.getCliente_idCliente());
		pstmt.setString(4, marcacao.getDataMarcacaoExame());
		pstmt.setString(5, marcacao.getHorarioMarcacao());
		pstmt.setString(6, marcacao.getLocalMarcacaoExame());
		pstmt.setInt(7, marcacao.getIdMarcacaoExame());
		pstmt.execute();
	}

	public ArrayList<MarcacaoExame> retornaTodasMarcacoes() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM marcacaoExame");

		ArrayList<MarcacaoExame> listaDeMarcacoes = new ArrayList<MarcacaoExame>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				
				MarcacaoExame marcacao = new MarcacaoExame();
				marcacao.setIdMarcacaoExame(rs.getInt("idMarcacaoExame"));
				marcacao.setExame_idExame(rs.getInt("Exame_idExame"));
				marcacao.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
				marcacao.setColaborador_idColaborador(rs.getInt("Colaborador_idColaborador"));
				marcacao.setCliente_idCliente(rs.getInt("Cliente_idCliente"));
				marcacao.setDataMarcacaoExame(rs.getString("dataMarcacaoExame"));
				marcacao.setHorarioMarcacao(rs.getString("horarioMarcacao"));
				marcacao.setLocalMarcacaoExame(rs.getString("localMarcacaoExame"));

				listaDeMarcacoes.add(marcacao);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaDeMarcacoes;
	}

}