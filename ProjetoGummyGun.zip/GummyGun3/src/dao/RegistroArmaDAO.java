package dao;

import java.sql.*;
import java.util.ArrayList;


import model.RegistroArma;

public class RegistroArmaDAO {
	private Connection con;

	public RegistroArmaDAO() {

		new Conexao();
		this.con = Conexao.obterConexao();
	}

	private static final String inserir = "INSERT INTO registroarma (nomeArma, registroArma, Cliente_idCliente, Usuario_idUsuario, validadeSinarm,"
			+ " cadastroSinarm, calibreArma, tirosArma, funcionamentoArma, paisFabArma, nfArma, datanfArma, validadeCRAF, expedicaoArma,"
			+ " serieArma, sigmaArma, tipoRegistro, obsArma)"
			+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String delete = "DELETE FROM registroarma WHERE idArma = ? ";
	private static final String update = "UPDATE registroarma SET nomeArma = ?, registroArma = ?, Cliente_idCliente = ?, Usuario_idUsuario = ?, "
			+ " validadeSinarm = ?, cadastroSinarm = ?, calibreArma = ?, tirosArma = ?, funcionamentoArma = ?, "
			+ " paisFabArma = ?, nfArma = ?, datanfArma = ?, "
			+ " validadeCRAF = ?, expedicaoArma = ?, serieArma = ?, sigmaArma = ?, tipoRegistro = ?, obsArma = ? WHERE idArma = ?";

	public void incluir(RegistroArma arma) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		pstmt.setString(1, arma.getNomeArma());
		pstmt.setString(2, arma.getRegistroArma());
		pstmt.setInt(3, arma.getCliente_idCliente());
		pstmt.setInt(4, arma.getUsuario_idUsuario());
		pstmt.setString(5, arma.getValidadeSinarm());
		pstmt.setString(6, arma.getCadastroSinarm());
		pstmt.setInt(7, arma.getCalibreArma());
		pstmt.setInt(8, arma.getTirosArma());
		pstmt.setString(9, arma.getFuncionamentoArma());
		pstmt.setString(10, arma.getPaisFabArma());
		pstmt.setString(11, arma.getNfArma());
		pstmt.setString(12, arma.getDatanfArma());
		pstmt.setString(13, arma.getValidadeCRAF());
		pstmt.setString(14, arma.getExpedicaoArma());
		pstmt.setString(15, arma.getSerieArma());
		pstmt.setInt(16, arma.getSigmaArma());
		pstmt.setString(17, arma.getTipoRegistro());
		pstmt.setString(18, arma.getObsArma());
		pstmt.execute();

	}

	public void deletar(RegistroArma arma) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setInt(1, arma.getIdArma());
		pstmt.execute();

	}

	public void alterar(RegistroArma arma) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);
		pstmt.setString(1, arma.getNomeArma());
		pstmt.setString(2, arma.getRegistroArma());
		pstmt.setInt(3, arma.getCliente_idCliente());
		pstmt.setInt(4, arma.getUsuario_idUsuario());
		pstmt.setString(5, arma.getValidadeSinarm());
		pstmt.setString(6, arma.getCadastroSinarm());
		pstmt.setInt(7, arma.getCalibreArma());
		pstmt.setInt(8, arma.getTirosArma());
		pstmt.setString(9, arma.getFuncionamentoArma());
		pstmt.setString(10, arma.getPaisFabArma());
		pstmt.setString(11, arma.getNfArma());
		pstmt.setString(12, arma.getDatanfArma());
		pstmt.setString(13, arma.getValidadeCRAF());
		pstmt.setString(14, arma.getExpedicaoArma());
		pstmt.setString(15, arma.getSerieArma());
		pstmt.setInt(16, arma.getSigmaArma());
		pstmt.setString(17, arma.getTipoRegistro());
		pstmt.setString(18, arma.getObsArma());
		pstmt.setInt(19, arma.getIdArma());
		pstmt.execute();

	}

	public ArrayList<RegistroArma> retornaTodosRegistros() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM registroArma");
		ArrayList<RegistroArma> listaderegistro = new ArrayList<RegistroArma>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {

				RegistroArma arma = new RegistroArma();

				arma.setIdArma(rs.getInt("idArma"));
				arma.setNomeArma(rs.getString("NomeArma"));
				arma.setRegistroArma(rs.getString("registroArma"));
				arma.setCliente_idCliente(rs.getInt("cliente_idCliente"));
				arma.setUsuario_idUsuario(rs.getInt("usuario_idUsuario"));
				arma.setValidadeSinarm(rs.getString("validadeSinarm"));
				arma.setCadastroSinarm(rs.getString("cadastroSinarm"));
				arma.setCalibreArma(rs.getInt("calibreArma"));
				arma.setTirosArma(rs.getInt("tirosArma"));
				arma.setFuncionamentoArma(rs.getString("funcionamentoArma"));
				arma.setPaisFabArma(rs.getString("paisFabArma"));
				arma.setNfArma(rs.getString("nfArma"));
				arma.setDatanfArma(rs.getString("datanfArma"));
				arma.setValidadeCRAF(rs.getString("validadeCRAF"));
				arma.setExpedicaoArma(rs.getString("expedicaoArma"));
				arma.setSerieArma(rs.getString("serieArma"));
				arma.setSigmaArma(rs.getInt("sigmaArma"));
				arma.setTipoRegistro(rs.getString("tipoRegistro"));
				arma.setObsArma(rs.getString("obsArma"));

				listaderegistro.add(arma);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listaderegistro;

	}

	public ArrayList<RegistroArma> pesquisaArmas(RegistroArma arma) {
		
		StringBuilder sql = new StringBuilder();

		sql.append("SELECT * FROM registroarma where registroArma like'%");
		sql.append(arma.getRegistroArma() + "%'");

		ArrayList<RegistroArma> listarArma = new ArrayList<RegistroArma>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				
				RegistroArma arma1 = new RegistroArma();

				arma1.setIdArma(rs.getInt("idArma"));
				arma1.setNomeArma(rs.getString("NomeArma"));
				arma1.setRegistroArma(rs.getString("registroArma"));
				arma1.setCliente_idCliente(rs.getInt("cliente_idCliente"));
				arma1.setUsuario_idUsuario(rs.getInt("usuario_idUsuario"));
				arma1.setValidadeSinarm(rs.getString("validadeSinarm"));
				arma1.setCadastroSinarm(rs.getString("cadastroSinarm"));
				arma1.setCalibreArma(rs.getInt("calibreArma"));
				arma1.setTirosArma(rs.getInt("tirosArma"));
				arma1.setFuncionamentoArma(rs.getString("funcionamentoArma"));
				arma1.setPaisFabArma(rs.getString("paisFabArma"));
				arma1.setNfArma(rs.getString("nfArma"));
				arma1.setDatanfArma(rs.getString("datanfArma"));
				arma1.setValidadeCRAF(rs.getString("validadeCRAF"));
				arma1.setExpedicaoArma(rs.getString("expedicaoArma"));
				arma1.setSerieArma(rs.getString("serieArma"));
				arma1.setSigmaArma(rs.getInt("sigmaArma"));
				arma1.setTipoRegistro(rs.getString("tipoRegistro"));
				arma1.setObsArma(rs.getString("obsArma"));


				listarArma.add(arma1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listarArma;
	}
}
