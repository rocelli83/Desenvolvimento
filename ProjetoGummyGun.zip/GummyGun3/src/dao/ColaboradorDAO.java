package dao;

import java.sql.*;
import java.util.ArrayList;

import model.Colaborador;

public class ColaboradorDAO {

	private Connection con;

	public ColaboradorDAO() {
		new Conexao();
		this.con = Conexao.obterConexao();

	}
	private static final String inserir = "INSERT INTO colaborador (nomeColaborador, cpfColaborador, profissaoColaborador, telColaborador,"
			+ " emailColaborador, enderecoColaborador, registroColaborador, Usuario_idUsuario) "
			+ "values (?,?,?,?,?,?,?,?)";
	private static final String delete = "DELETE FROM colaborador WHERE idColaborador = ?";
	private static final String update = "UPDATE colaborador SET "
			+ "nomeColaborador = ?, cpfColaborador = ?, profissaoColaborador = ?, telColaborador = ?,"
			+ " emailColaborador = ?, enderecoColaborador = ?, registroColaborador = ?"
			+ " WHERE idColaborador = ?";

	
	
	public void incluir(Colaborador colaborador) throws SQLException{
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		
		pstmt.setString(1, colaborador.getNomeColaborador());
		pstmt.setLong(2, colaborador.getCpfColaborador());
		pstmt.setString(3, colaborador.getProfissaoColaborador());
		pstmt.setString(4, colaborador.getTelColaborador());
		pstmt.setString(5, colaborador.getEmailColaborador());
		pstmt.setString(6, colaborador.getEnderecoColaborador());
		pstmt.setString(7, colaborador.getRegistroColaborador());
		pstmt.setInt(8, colaborador.getUsuario_idUsuario());
		pstmt.execute();
	}
	
	public void deletar(Colaborador colaborador) throws SQLException {

		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setInt(1, colaborador.getIdColaborador());
		pstmt.execute();
	}
	
	public void alterar(Colaborador colaborador) throws SQLException{
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);
		pstmt.setString(1, colaborador.getNomeColaborador());
		pstmt.setLong(2, colaborador.getCpfColaborador());
		pstmt.setString(3, colaborador.getProfissaoColaborador());
		pstmt.setString(4, colaborador.getTelColaborador());
		pstmt.setString(5, colaborador.getEmailColaborador());
		pstmt.setString(6, colaborador.getEnderecoColaborador());
		pstmt.setString(7, colaborador.getRegistroColaborador());
		pstmt.setInt(8, colaborador.getIdColaborador());
		pstmt.execute();
	}
	
	public ArrayList<Colaborador> retornaTodosColaboradores() {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM colaborador");

		ArrayList<Colaborador> listaDeColaboradores = new ArrayList<Colaborador>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				Colaborador colaborador = new Colaborador();
				
				colaborador.setIdColaborador(rs.getInt("idColaborador"));
				colaborador.setNomeColaborador(rs.getString("nomeColaborador"));
				colaborador.setCpfColaborador(rs.getLong("cpfColaborador"));
				colaborador.setProfissaoColaborador(rs.getString("profissaoColaborador"));
				colaborador.setTelColaborador(rs.getString("telColaborador"));
				colaborador.setEmailColaborador(rs.getString("emailColaborador"));
				colaborador.setEnderecoColaborador(rs.getString("enderecoColaborador"));
				colaborador.setRegistroColaborador(rs.getString("registroColaborador"));
				colaborador.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
				
				listaDeColaboradores.add(colaborador);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaDeColaboradores;
	}
	public ArrayList<Colaborador> pesquisaColaboradores(Colaborador colaborador) {
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM colaborador where nomeColaborador like'%");
		sql.append(colaborador.getNomeColaborador()+"%'");
		
		ArrayList<Colaborador> listarColaboradores = new ArrayList<Colaborador>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				Colaborador colaborador1 = new Colaborador();
				
				colaborador1.setIdColaborador(rs.getInt("idColaborador"));
				colaborador1.setNomeColaborador(rs.getString("nomeColaborador"));
				colaborador1.setCpfColaborador(rs.getLong("cpfColaborador"));
				colaborador1.setProfissaoColaborador(rs.getString("profissaoColaborador"));
				colaborador1.setTelColaborador(rs.getString("telColaborador"));
				colaborador1.setEmailColaborador(rs.getString("emailColaborador"));
				colaborador1.setEnderecoColaborador(rs.getString("enderecoColaborador"));
				colaborador1.setRegistroColaborador(rs.getString("registroColaborador"));
				colaborador1.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
				
				listarColaboradores.add(colaborador1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listarColaboradores;
	}
}
