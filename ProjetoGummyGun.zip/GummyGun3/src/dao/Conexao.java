package dao;

import java.sql.*;

public class Conexao {
	
	public static String status ="";
	
	public static Connection obterConexao(){
		Connection con = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String url = "jdbc:mysql://127.0.0.1/tirorapido?user=root&password=123456";
			con = DriverManager.getConnection(url);
			
			status = "Conex�o aberta";
		}
		catch (InstantiationException e){
			e.printStackTrace();
			
		} catch (IllegalAccessException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return con;
	}

}