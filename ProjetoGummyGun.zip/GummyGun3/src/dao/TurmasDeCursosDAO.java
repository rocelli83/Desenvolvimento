package dao;

import java.sql.*;
import java.util.ArrayList;


import model.TurmasDeCurso;


public class TurmasDeCursosDAO {
	
	private Connection con;

	public TurmasDeCursosDAO() {
	
		new Conexao();
		this.con = Conexao.obterConexao();
	}
	
	private static final String inserir = "INSERT INTO turmasdecurso (Curso_idCurso, Colaborador_idColaborador,"
			+ "localTurma, horarioTurma, numeroAlunosTurma, dataTurma, Usuario_idUsuario, nomeTurma) "
			+ "values (?,?,?,?,?,?,?,?)";
	private static final String delete = "DELETE FROM turmasdecurso WHERE idTurma = ? ";
	private static final String update = "UPDATE turmasdecurso SET "
			+ "localTurma = ?, horarioTurma = ?, dataTurma = ?, nomeTurma = ? WHERE idTurma = ?";
	
	public void incluir(TurmasDeCurso turmas) throws SQLException{
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(inserir);
		pstmt.setInt(1, turmas.getCurso_idCurso());
	
		pstmt.setInt(2, turmas.getColaborador_idColaborador());
		pstmt.setString(3, turmas.getLocalTurma());
		pstmt.setString(4, turmas.getHorarioTurma());
		pstmt.setInt(5, turmas.getNumeroAlunosTurma());
		pstmt.setString(6, turmas.getDataTurma());
		pstmt.setInt(7, turmas.getUsuario_idUsuario());
		pstmt.setString(8, turmas.getNomeTurma());
		pstmt.execute();
		
	}
	
	public void deletar(TurmasDeCurso turmas) throws SQLException{
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(delete);
		pstmt.setInt(1, turmas.getIdTurma());
	
		pstmt.execute();
	}
	
	public void alterar(TurmasDeCurso turmas) throws SQLException{
		
		PreparedStatement pstmt = (PreparedStatement) con.prepareStatement(update);
		
		pstmt.setString(1, turmas.getLocalTurma());
		pstmt.setString(2, turmas.getHorarioTurma());
		pstmt.setString(3, turmas.getDataTurma());
		pstmt.setString(4, turmas.getNomeTurma());
		pstmt.setInt(5, turmas.getIdTurma());
		pstmt.execute();
	}
	
	public ArrayList<TurmasDeCurso> retornaTodasTurmas() {
		
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * FROM turmasdecurso");

		ArrayList<TurmasDeCurso> listaDeTurmas = new ArrayList<TurmasDeCurso>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			
			while (rs.next()) {
				
				TurmasDeCurso turmas = new TurmasDeCurso();
				
				turmas.setIdTurma(rs.getInt("idTurma"));
				turmas.setNomeTurma(rs.getString("nomeTurma"));
				turmas.setCurso_idCurso(rs.getInt("Curso_idCurso"));

				turmas.setColaborador_idColaborador(rs.getInt("Colaborador_idColaborador"));
				turmas.setLocalTurma(rs.getString("localTurma"));
				turmas.setHorarioTurma(rs.getString("horarioTurma"));
				turmas.setNumeroAlunosTurma(rs.getInt("numeroAlunosTurma"));
				turmas.setDataTurma(rs.getString("dataTurma"));
				turmas.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
				
				
				listaDeTurmas.add(turmas);
			}
			st.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listaDeTurmas;
	}
	public ArrayList<TurmasDeCurso> pesquisaTurmas(TurmasDeCurso turma) {
		
		StringBuilder sql = new StringBuilder();

		sql.append("SELECT * FROM turmasdecurso WHERE nomeTurma like'%");
		sql.append(turma.getNomeTurma()+ "%'");

		ArrayList<TurmasDeCurso> listarTurma = new ArrayList<TurmasDeCurso>();

		try {
			Connection con = Conexao.obterConexao();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql.toString());
			while (rs.next()) {
				
				TurmasDeCurso turma1 = new TurmasDeCurso();
				
				turma1.setIdTurma(rs.getInt("idTurma"));
				turma1.setNomeTurma(rs.getString("nomeTurma"));
				turma1.setCurso_idCurso(rs.getInt("Curso_idCurso"));
			
				turma1.setColaborador_idColaborador(rs.getInt("Colaborador_idColaborador"));
				turma1.setLocalTurma(rs.getString("localTurma"));
				turma1.setHorarioTurma(rs.getString("horarioTurma"));
				turma1.setNumeroAlunosTurma(rs.getInt("numeroAlunosTurma"));
				turma1.setDataTurma(rs.getString("dataTurma"));
				turma1.setUsuario_idUsuario(rs.getInt("Usuario_idUsuario"));
				
				
				listarTurma.add(turma1);
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return listarTurma;
	}
}


