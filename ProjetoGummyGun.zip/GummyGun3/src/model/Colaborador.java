package model;

public class Colaborador {

	private int idColaborador;
	private String nomeColaborador;
	private long cpfColaborador;
	private String profissaoColaborador;
	private String telColaborador;
	private String emailColaborador;
	private String enderecoColaborador;
	private String registroColaborador;
	private int Usuario_idUsuario;

	public int getIdColaborador() {
		return idColaborador;
	}

	public void setIdColaborador(int idColaborador) {
		this.idColaborador = idColaborador;
	}

	public String getNomeColaborador() {
		return nomeColaborador;
	}

	public void setNomeColaborador(String nomeColaborador) {
		this.nomeColaborador = nomeColaborador;
	}

	public long getCpfColaborador() {
		return cpfColaborador;
	}

	public void setCpfColaborador(long cpfColaborador) {
		this.cpfColaborador = cpfColaborador;
	}

	public String getProfissaoColaborador() {
		return profissaoColaborador;
	}

	public void setProfissaoColaborador(String profissaoColaborador) {
		this.profissaoColaborador = profissaoColaborador;
	}

	public String getTelColaborador() {
		return telColaborador;
	}

	public void setTelColaborador(String telColaborador) {
		this.telColaborador = telColaborador;
	}

	public String getEmailColaborador() {
		return emailColaborador;
	}

	public void setEmailColaborador(String emailColaborador) {
		this.emailColaborador = emailColaborador;
	}

	public String getEnderecoColaborador() {
		return enderecoColaborador;
	}

	public void setEnderecoColaborador(String enderecoColaborador) {
		this.enderecoColaborador = enderecoColaborador;
	}

	public String getRegistroColaborador() {
		return registroColaborador;
	}

	public void setRegistroColaborador(String registroColaborador) {
		this.registroColaborador = registroColaborador;
	}

	public int getUsuario_idUsuario() {
		return Usuario_idUsuario;
	}

	public void setUsuario_idUsuario(int usuario_idUsuario) {
		Usuario_idUsuario = usuario_idUsuario;
	}

}
