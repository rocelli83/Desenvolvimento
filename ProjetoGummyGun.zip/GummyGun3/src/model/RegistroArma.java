package model;

public class RegistroArma {

	private int idArma;
	private String nomeArma; //numeroArma
	private String registroArma;
	private int Cliente_idCliente;
	private int Usuario_idUsuario;
	private String validadeSinarm;
	private String cadastroSinarm;
	private int calibreArma;
	private int tirosArma;
	private String funcionamentoArma;
	private String paisFabArma;
	private String nfArma;
	private String datanfArma;
	private String validadeCRAF;
	private String expedicaoArma;
	private String serieArma;
	private int sigmaArma;
	private String tipoRegistro;
	private String obsArma;
	
	public int getIdArma() {
		return idArma;
	}
	public void setIdArma(int idArma) {
		this.idArma = idArma;
	}
	public String getNomeArma() {
		return nomeArma;
	}
	public void setNomeArma(String nomeArma) {
		this.nomeArma = nomeArma;
	}
	public String getRegistroArma() {
		return registroArma;
	}
	public void setRegistroArma(String registroArma) {
		this.registroArma = registroArma;
	}
	public int getCliente_idCliente() {
		return Cliente_idCliente;
	}
	public void setCliente_idCliente(int cliente_idCliente) {
		Cliente_idCliente = cliente_idCliente;
	}
	public int getUsuario_idUsuario() {
		return Usuario_idUsuario;
	}
	public void setUsuario_idUsuario(int usuario_idUsuario) {
		Usuario_idUsuario = usuario_idUsuario;
	}
	public String getValidadeSinarm() {
		return validadeSinarm;
	}
	public void setValidadeSinarm(String validadeSinarm) {
		this.validadeSinarm = validadeSinarm;
	}
	public String getCadastroSinarm() {
		return cadastroSinarm;
	}
	public void setCadastroSinarm(String cadastroSinarm) {
		this.cadastroSinarm = cadastroSinarm;
	}
	public int getCalibreArma() {
		return calibreArma;
	}
	public void setCalibreArma(int calibreArma) {
		this.calibreArma = calibreArma;
	}
	public int getTirosArma() {
		return tirosArma;
	}
	public void setTirosArma(int tirosArma) {
		this.tirosArma = tirosArma;
	}
	public String getFuncionamentoArma() {
		return funcionamentoArma;
	}
	public void setFuncionamentoArma(String funcionamentoArma) {
		this.funcionamentoArma = funcionamentoArma;
	}
	public String getPaisFabArma() {
		return paisFabArma;
	}
	public void setPaisFabArma(String paisFabArma) {
		this.paisFabArma = paisFabArma;
	}
	public String getNfArma() {
		return nfArma;
	}
	public void setNfArma(String nfArma) {
		this.nfArma = nfArma;
	}
	public String getDatanfArma() {
		return datanfArma;
	}
	public void setDatanfArma(String datanfArma) {
		this.datanfArma = datanfArma;
	}
	public String getValidadeCRAF() {
		return validadeCRAF;
	}
	public void setValidadeCRAF(String validadeCRAF) {
		this.validadeCRAF = validadeCRAF;
	}
	public String getExpedicaoArma() {
		return expedicaoArma;
	}
	public void setExpedicaoArma(String expedicaoArma) {
		this.expedicaoArma = expedicaoArma;
	}
	public String getSerieArma() {
		return serieArma;
	}
	public void setSerieArma(String serieArma) {
		this.serieArma = serieArma;
	}
	public int getSigmaArma() {
		return sigmaArma;
	}
	public void setSigmaArma(int sigmaArma) {
		this.sigmaArma = sigmaArma;
	}
	public String getTipoRegistro() {
		return tipoRegistro;
	}
	public void setTipoRegistro(String tipoRegistro) {
		this.tipoRegistro = tipoRegistro;
	}
	public String getObsArma() {
		return obsArma;
	}
	public void setObsArma(String obsArma) {
		this.obsArma = obsArma;
	}
	
}