package model;

public class TurmasDeCurso {

	private int idTurma;
	private String nomeTurma;
	private int Curso_idCurso;
	private int Cliente_idCliente;
	private int Colaborador_idColaborador;
	private String localTurma;
	private String horarioTurma;
	private int numeroAlunosTurma;
	private String dataTurma;
	private int Usuario_idUsuario;

	public int getIdTurma() {
		return idTurma;
	}

	public void setIdTurma(int idTurma) {
		this.idTurma = idTurma;
	}

	public String getNomeTurma() {
		return nomeTurma;
	}

	public void setNomeTurma(String nomeTurma) {
		this.nomeTurma = nomeTurma;
	}

	public int getCurso_idCurso() {
		return Curso_idCurso;
	}

	public void setCurso_idCurso(int curso_idCurso) {
		Curso_idCurso = curso_idCurso;
	}

	public int getCliente_idCliente() {
		return Cliente_idCliente;
	}

	public void setCliente_idCliente(int cliente_idCliente) {
		Cliente_idCliente = cliente_idCliente;
	}

	public int getColaborador_idColaborador() {
		return Colaborador_idColaborador;
	}

	public void setColaborador_idColaborador(int colaborador_idColaborador) {
		Colaborador_idColaborador = colaborador_idColaborador;
	}

	public String getLocalTurma() {
		return localTurma;
	}

	public void setLocalTurma(String localTurma) {
		this.localTurma = localTurma;
	}

	public String getHorarioTurma() {
		return horarioTurma;
	}

	public void setHorarioTurma(String horarioTurma) {
		this.horarioTurma = horarioTurma;
	}

	public int getNumeroAlunosTurma() {
		return numeroAlunosTurma;
	}

	public void setNumeroAlunosTurma(int numeroAlunosTurma) {
		this.numeroAlunosTurma = numeroAlunosTurma;
	}

	public String getDataTurma() {
		return dataTurma;
	}

	public void setDataTurma(String dataTurma) {
		this.dataTurma = dataTurma;
	}

	public int getUsuario_idUsuario() {
		return Usuario_idUsuario;
	}

	public void setUsuario_idUsuario(int usuario_idUsuario) {
		Usuario_idUsuario = usuario_idUsuario;
	}

}
