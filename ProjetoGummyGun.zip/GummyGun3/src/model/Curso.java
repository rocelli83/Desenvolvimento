package model;

public class Curso {

	private int idCurso;
	private String nomeCurso;
	private String categoriaCurso;
	private double valorCurso;
	private int Usuario_idUsuario;

	public int getIdCurso() {
		return idCurso;
	}

	public void setIdCurso(int idCurso) {
		this.idCurso = idCurso;
	}

	public String getNomeCurso() {
		return nomeCurso;
	}

	public void setNomeCurso(String nomeCurso) {
		this.nomeCurso = nomeCurso;
	}

	public String getCategoriaCurso() {
		return categoriaCurso;
	}

	public void setCategoriaCurso(String categoriaCurso) {
		this.categoriaCurso = categoriaCurso;
	}

	public double getValorCurso() {
		return valorCurso;
	}

	public void setValorCurso(double valorCurso) {
		this.valorCurso = valorCurso;
	}

	public int getUsuario_idUsuario() {
		return Usuario_idUsuario;
	}

	public void setUsuario_idUsuario(int usuario_idUsuario) {
		Usuario_idUsuario = usuario_idUsuario;
	}

}
