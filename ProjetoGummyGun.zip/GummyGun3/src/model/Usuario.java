package model;

public class Usuario {
			
	private int idUsuario;
	private String loginUsuario;
	private String senhaUsuario;
	private String emailUsuario;
	private int acessoUsuario;
	
	
	public int getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public String getLoginUsuario() {
		return loginUsuario;
	}
	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}
	public String getSenhaUsuario() {
		return senhaUsuario;
	}
	public void setSenhaUsuario(String senhaUsuario) {
		this.senhaUsuario = senhaUsuario;
	}
	public String getEmailUsuario() {
		return emailUsuario;
	}
	public void setEmailUsuario(String emailUsuario) {
		this.emailUsuario = emailUsuario;
	}
	public int getAcessoUsuario() {
		return acessoUsuario;
	}
	public void setAcessoUsuario(int acessoUsuario) {
		this.acessoUsuario = acessoUsuario;
	}
	
	
}