package model;

public class MarcacaoExame {
	
	private int idMarcacaoExame;
	private int Exame_idExame;
	private int Usuario_idUsuario;
	private int Colaborador_idColaborador;
	private int Cliente_idCliente;
	private String dataMarcacaoExame;
	private String horarioMarcacao;
	private String localMarcacaoExame;
	
	public int getIdMarcacaoExame() {
		return idMarcacaoExame;
	}

	public void setIdMarcacaoExame(int idMarcacaoExame) {
		this.idMarcacaoExame = idMarcacaoExame;
	}

	public int getExame_idExame() {
		return Exame_idExame;
	}

	public void setExame_idExame(int exame_idExame) {
		Exame_idExame = exame_idExame;
	}

	public int getUsuario_idUsuario() {
		return Usuario_idUsuario;
	}

	public void setUsuario_idUsuario(int usuario_idUsuario) {
		Usuario_idUsuario = usuario_idUsuario;
	}

	public int getColaborador_idColaborador() {
		return Colaborador_idColaborador;
	}

	public void setColaborador_idColaborador(int colaborador_idColaborador) {
		Colaborador_idColaborador = colaborador_idColaborador;
	}

	public int getCliente_idCliente() {
		return Cliente_idCliente;
	}

	public void setCliente_idCliente(int cliente_idCliente) {
		Cliente_idCliente = cliente_idCliente;
	}

	public String getDataMarcacaoExame() {
		return dataMarcacaoExame;
	}

	public void setDataMarcacaoExame(String dataMarcacaoExame) {
		this.dataMarcacaoExame = dataMarcacaoExame;
	}

	public String getHorarioMarcacao() {
		return horarioMarcacao;
	}

	public void setHorarioMarcacao(String horarioMarcacao) {
		this.horarioMarcacao = horarioMarcacao;
	}

	public String getLocalMarcacaoExame() {
		return localMarcacaoExame;
	}

	public void setLocalMarcacaoExame(String localMarcacaoExame) {
		this.localMarcacaoExame = localMarcacaoExame;
	}

}
