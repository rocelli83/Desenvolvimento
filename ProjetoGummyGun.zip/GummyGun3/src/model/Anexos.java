package model;

public class Anexos {

	private int idAnexos;
	private String documentosPessoais;
	private String anexosEB;
	private String anexosPF;
	private String anexosArma;
	private int Cliente_idCliente;
	private int Usuario_idUsuario;

	public int getIdAnexos() {
		return idAnexos;
	}

	public void setIdAnexos(int idAnexos) {
		this.idAnexos = idAnexos;
	}

	public String getDocumentosPessoais() {
		return documentosPessoais;
	}

	public void setDocumentosPessoais(String documentosPessoais) {
		this.documentosPessoais = documentosPessoais;
	}

	public String getAnexosEB() {
		return anexosEB;
	}

	public void setAnexosEB(String anexosEB) {
		this.anexosEB = anexosEB;
	}

	public String getAnexosPF() {
		return anexosPF;
	}

	public void setAnexosPF(String anexosPF) {
		this.anexosPF = anexosPF;
	}

	public String getAnexosArma() {
		return anexosArma;
	}

	public void setAnexosArma(String anexosArma) {
		this.anexosArma = anexosArma;
	}

	public int getCliente_idCliente() {
		return Cliente_idCliente;
	}

	public void setCliente_idCliente(int cliente_idCliente) {
		Cliente_idCliente = cliente_idCliente;
	}

	public int getUsuario_idUsuario() {
		return Usuario_idUsuario;
	}

	public void setUsuario_idUsuario(int usuario_idUsuario) {
		Usuario_idUsuario = usuario_idUsuario;
	}

}
