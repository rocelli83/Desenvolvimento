package model;

public class Turma_Cliente {
		
	private int idTurma_Cliente;
	private int Cliente_idCliente;
	private int Turma_idTurma;
	
	public int getIdTurma_Cliente() {
		return idTurma_Cliente;
	}
	public void setIdTurma_Cliente(int idTurma_Cliente) {
		this.idTurma_Cliente = idTurma_Cliente;
	}
	public int getCliente_idCliente() {
		return Cliente_idCliente;
	}
	public void setCliente_idCliente(int cliente_idCliente) {
		Cliente_idCliente = cliente_idCliente;
	}
	public int getTurma_idTurma() {
		return Turma_idTurma;
	}
	public void setTurma_idTurma(int turma_idTurma) {
		Turma_idTurma = turma_idTurma;
	}
	
	
}
