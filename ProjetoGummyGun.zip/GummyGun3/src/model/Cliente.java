package model;

import java.util.Date;

public class Cliente {

	private int idCliente;
	private String nomeCliente;
	private long cpfCnpjCliente;
	private String emailCliente;
	private String rgCliente;
	private String dataNascCliente;
	private String endCliente;
	private String telCliente;
	private String protocoloCliente;
	private String dataCadastroCliente;
	private String celCliente;
	private int Usuario_idUsuario;

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public long getCpfCnpjCliente() {
		return cpfCnpjCliente;
	}

	public void setCpfCnpjCliente(long cpfCnpjCliente) {
		this.cpfCnpjCliente = cpfCnpjCliente;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public String getRgCliente() {
		return rgCliente;
	}

	public void setRgCliente(String rgCliente) {
		this.rgCliente = rgCliente;
	}



	public String getEndCliente() {
		return endCliente;
	}

	public void setEndCliente(String endCliente) {
		this.endCliente = endCliente;
	}

	public String getTelCliente() {
		return telCliente;
	}

	public void setTelCliente(String telCliente) {
		this.telCliente = telCliente;
	}

	public String getProtocoloCliente() {
		return protocoloCliente;
	}

	public void setProtocoloCliente(String protocoloCliente) {
		this.protocoloCliente = protocoloCliente;
	}


	public String getCelCliente() {
		return celCliente;
	}

	public void setCelCliente(String celCliente) {
		this.celCliente = celCliente;
	}

	public String getDataNascCliente() {
		return dataNascCliente;
	}

	public void setDataNascCliente(String dataNascCliente) {
		this.dataNascCliente = dataNascCliente;
	}

	public String getDataCadastroCliente() {
		return dataCadastroCliente;
	}

	public void setDataCadastroCliente(String dataCadastroCliente) {
		this.dataCadastroCliente = dataCadastroCliente;
	}

	public int getUsuario_idUsuario() {
		return Usuario_idUsuario;
	}

	public void setUsuario_idUsuario(int usuario_idUsuario) {
		Usuario_idUsuario = usuario_idUsuario;
	}
	

}
