/*
Copyright (c) 2014, comScore Inc. All rights reserved.
version: 5.0.3
*/

function readCookie(name){
  var ca = document.cookie.split(';');
  var nameEQ = name + "=";
  for(var i=0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0)==' ') c = c.substring(1, c.length); //delete spaces
    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
  return false;
}
function _set_SessionCookie(_url){
 _url = _url.replace(/^http(s)?\:\/\/(www|)microsoft\.com\//i, '');
 	if(COMSCORE.isDDInProgress()){
		c_urls = readCookie("captlinks");
		if(c_urls){
   		if(c_urls.search(_url) == -1){
   			var str = c_urls +"," + _url;
   			if(str.length <= 1040){
   				_url = str;
   			}else{ _url=false; }
   		}else{ _url = false; }
  	}
  	if(_url){
  		var c = 'captlinks=' + _url                             
      		            + '; path=/'
                      + '; domain=.microsoft.com';
                document.cookie = c;    
    }
 	}
}
var allLinks = document.getElementsByTagName("a");
for (var i = 0, n = allLinks.length; i < n; i++){	
		if(allLinks[i].addEventListener){
			allLinks[i].addEventListener('click',function(event){
					_set_SessionCookie(this.href);
				},false);
		}else{
			hrefURL = allLinks[i].href;
			allLinks[i].attachEvent('onclick',function(){
				_set_SessionCookie(hrefURL);
				});
		}
}

COMSCORE.SiteRecruit.Broker.config = {
	version: "5.0.3",
	//TODO:Karl extend cookie enhancements to ie userdata
		testMode: false,
	
	// cookie settings
	cookie:{
		name: 'msresearch',
		path: '/',
		domain:  '.microsoft.com' ,
		duration: 90,
		rapidDuration: 0,
		expireDate: ''
	},
	thirdPartyOptOutCookieEnabled : false,
	
	// optional prefix for pagemapping's pageconfig file
	prefixUrl: "",
	
	//events
	Events: {
		beforeRecruit: function() {
			if(/events\.microsoftvirtualacademy\.com/i.test(window.location.toString()) ){
				COMSCORE.SiteRecruit.Broker.config.mapping[0].halt = true;
			}
					}
	},
	
		mapping:[
	// m=regex match, c=page config file (prefixed with configUrl), f=frequency
	{m: '', c: 'inv_c_virtualacademy.js', f: 0.0168, p: 0 	}
	,{m: 'pt-BR', c: 'inv_c_virtualacademy_PT-BR.js', f: 0.5, p: 1 	}
	,{m: 'es-es', c: 'inv_c_virtualacademy_ES-ES.js', f: 0.5, p: 1 	}
]
};

window.setTimeout('COMSCORE.SiteRecruit.Broker.run()', 1000);