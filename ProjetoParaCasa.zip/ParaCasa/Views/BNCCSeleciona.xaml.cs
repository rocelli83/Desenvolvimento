﻿using ParaCasa.Models;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ParaCasa.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BNCCSeleciona : Page
    {
        private ObservableCollection<Bncc> Bncc;

        Bncc bncc = new Bncc();

       

        public BNCCSeleciona()
        {
            this.InitializeComponent();
            var ano = cbAno.SelectionBoxItem;


        }
        //Método para popular combobox
        private void popularArea()
        {
            try
            {
                var bdao = new Bncc();
                Bncc = new ObservableCollection<Bncc>();
                bdao.retornaArea(Bncc);
            }
            catch (SQLiteException erro)
            {
                erro.Message.ToString();
            }
        }
        private void AppBarButton_Click(object sender, RoutedEventArgs e)
        {
            Bncc cbbncc = (Bncc) cbAno.SelectionBoxItem;
            cbbncc = (Bncc)cbArea.SelectionBoxItem;
            cbbncc = (Bncc)cbMateria.SelectionBoxItem;
                
        }

        private void AppBarButton_Tapped(object sender, TappedRoutedEventArgs e)
        {

        }

        private void AppBarButton_Tapped_1(object sender, TappedRoutedEventArgs e)
        {

        }

        private void AppBarButton_Tapped_2(object sender, TappedRoutedEventArgs e)
        {

        }

        
    }
}
