﻿using ParaCasa.Controller;
using ParaCasa.Models;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ParaCasa.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CadastrarAluno : Page
    {
        private ObservableCollection<Escola> Escolas;

        Aluno aluno = new Aluno();

        Perfil perfil = new Perfil();

        Usuario usuario = new Usuario();
        
        public CadastrarAluno()
        {
            this.InitializeComponent();
     
        }

        
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
           perfil = (Perfil)e.Parameter;
            popular();
            txbUserEmail.Text = perfil.emailPerfil;
        }

        //Método para popular combobox
        private void popular()
        {
            try {
                var dao = new Escola();
                Escolas = new ObservableCollection<Escola>();
                dao.RetornaEscolaPorMunicipio(Escolas, perfil.cidadePerfil);
            }
            catch(SQLiteException erro)
            {
                erro.Message.ToString();
            }
        }

 
        private void btnEntrar_Click(object sender, RoutedEventArgs e)
        {
            //Dados Aluno
            aluno.Perfil_idPerfil = perfil.idPerfil;
            aluno.matriculaAluno = txtMatricula.Text;
            ComboBoxItem cbItem = (ComboBoxItem)cbAno.SelectedValue;
            Escola escola = (Escola)cbEscola.SelectionBoxItem;
            aluno.anoAluno = int.Parse(cbItem.DataContext.ToString());
            aluno.Escola_idEscola = (int)escola.Codigo_da_Escola;


            try {
                // Inserir Aluno no banco
                AlunoDao dao = new AlunoDao();
                aluno.idAluno = (int)dao.InserirAluno(aluno.Perfil_idPerfil, aluno.matriculaAluno, aluno.anoAluno, aluno.Escola_idEscola);
                perfil.Perfil_idAluno = aluno.idAluno;
                var pdao = new PerfilDao();
                pdao.CadastraPerfilAluno(perfil);


                //Cadastrar Usuário
                UsuarioDao udao = new UsuarioDao();
                usuario.nomeUsuario = perfil.emailPerfil;
                usuario.senhaUsuario = pwdSenha.Password;
                usuario.Perfil_idAluno = aluno.idAluno;
                usuario.Perfil_idPerfil = perfil.idPerfil;
                udao.InserirUsuario(usuario);
            }

        catch(SQLiteException erro)
            {
                erro.Message.ToString();
            }

            Frame.Navigate(typeof(PerfilAluno), aluno);
        }

        private void cbAno_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void svCadastro_ViewChanged(object sender, ScrollViewerViewChangedEventArgs e)
        {

        }
    }
}