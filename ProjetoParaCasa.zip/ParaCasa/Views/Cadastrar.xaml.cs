﻿using ParaCasa.Controller;
using ParaCasa.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ParaCasa.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Cadastrar : Page
    {
        string radio;
        private ObservableCollection<Escola> Escolas;
        public Cadastrar()
        {
            this.InitializeComponent();
            var edao = new Escola();
                      
            Escolas = new ObservableCollection<Escola>();
            edao.retornaMunicipio(Escolas);
        }


        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton option = sender as RadioButton;
            radio = option.Content.ToString();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            var user = e.Parameter;

        }

        private void btnAvancar_Click(object sender, RoutedEventArgs e)
        {
            Perfil perfil = new Perfil();

            perfil.nomePerfil = txtNome.Text;
            perfil.emailPerfil = txtEmail.Text;
            perfil.dataNascPerfil = dpNascimento.Date;
            ComboBoxItem cbItem= (ComboBoxItem)cbEstado.SelectedValue;
            Escola escola = (Escola)cbCidade.SelectionBoxItem;
            perfil.estadoPerfil = cbItem.DataContext.ToString();
            perfil.cidadePerfil = escola.municipio;

      
            // Inserir Perfil
            PerfilDao dao = new PerfilDao();
            try {
                long id = dao.InserirPerfil(perfil.nomePerfil, perfil.emailPerfil, perfil.cidadePerfil, perfil.estadoPerfil, perfil.dataNascPerfil);
                perfil.idPerfil = (int)id;
            }
            catch(Exception)
            {

            }
            
            if ((bool)rbAluno.IsChecked)
            {
                Frame.Navigate(typeof(CadastrarAluno), perfil);
            }
            else
            {
                Frame.Navigate(typeof(CadastrarProfessor), perfil);
            }
        }

    }
}