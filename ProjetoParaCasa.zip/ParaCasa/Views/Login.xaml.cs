﻿using ParaCasa.Controller;
using ParaCasa.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Windows.Security.Credentials;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ParaCasa.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Login : Page
    {
        bool IsLoad;

        public Login()
        {
            if (RetrieveCredential("ParaCasaResource") == null)
            {
                this.InitializeComponent();
            }
            else
            {
           
                IsLoad = true;
            }
        }

        void SaveCredential(string username, string password)
        {
            PasswordVault vault = new PasswordVault();
            PasswordCredential cred = new PasswordCredential("ParaCasaResource", username, password);
            vault.Add(cred);
        }

        IReadOnlyList<PasswordCredential> RetrieveCredential(string resource)
        {
            try
            {
                PasswordVault vault = new PasswordVault();
                return vault.FindAllByResource(resource);
            }
            catch
            {
                return null;
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if(IsLoad)
            {
                //encaminhar para Perfil
            }
        }

        private void btnCadastro_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Cadastrar));
        }

        private void btnSenha_Click(object sender, RoutedEventArgs e)
        {
           if (ckbSalvar.IsChecked == true)
                SaveCredential(txtLogin.Text, pwdLogin.Password);
            this.Frame.Navigate(typeof(RecuperarSenha));
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {           
            Usuario user = new Usuario();
            Usuario logado = new Usuario();
            UsuarioDao dao = new UsuarioDao();
            
            user.nomeUsuario = txtLogin.Text;
            user.senhaUsuario = pwdLogin.Password;

            var usuario = dao.logarUsuario(user.nomeUsuario, user.senhaUsuario);

            logado = dao.dadosUsuario(user);
            
            if (!usuario)
            {
                txtLoginMsg.Text = ("usuario ou senha inválidos!");
            }
            else if(logado.Perfil_idAluno.Equals(null) || logado.Perfil_idAluno.Equals(0))
            {
                ProfessorDao adao = new ProfessorDao();
                Professor professor = adao.BuscaProfessor((int)logado.Perfil_idProfe);

                Frame.Navigate(typeof(PerfilProfessor), professor);
            }
            else
            {
                AlunoDao adao = new AlunoDao();
                Aluno aluno = adao.BuscaAluno((int)logado.Perfil_idAluno);
                Frame.Navigate(typeof(PerfilAluno), aluno);
            }

            
        }
    }
}