﻿using ParaCasa.Models;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ParaCasa.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BNCCArea : Page
    {
        private ObservableCollection<Bncc> Areas;

        public BNCCArea()
        {
            this.InitializeComponent();
            popular();
        }

        private void popular()
        {
            try
            {
                var dao = new Bncc();
                Areas = new ObservableCollection<Bncc>();
                dao.retornaArea(Areas);
            }
            catch (SQLiteException erro)
            {
                erro.Message.ToString();
            }
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            Bncc bncc = (Bncc)e.Parameter;
            AnoText.Text = bncc.ano.ToString();



        }

        private void ListView_ItemClick(object sender, ItemClickEventArgs e)
        {
            var bncc = (Bncc) e.ClickedItem;
            AreaText.Text ="Voce selecionou: " + bncc.area;
        }
    }
}
