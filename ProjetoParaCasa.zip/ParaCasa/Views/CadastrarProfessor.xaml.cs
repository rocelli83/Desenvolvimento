﻿using ParaCasa.Controller;
using ParaCasa.Models;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ParaCasa.Views
{
    
    public sealed partial class CadastrarProfessor : Page
    {
        Professor professor = new Professor();

        Perfil perfil = new Perfil();

        Usuario usuario = new Usuario();

        private ObservableCollection<Escola> Escolas;
        private ObservableCollection<Bncc> Bncc;

        public CadastrarProfessor()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            perfil = (Perfil)e.Parameter;
            txbUserEmail.Text = perfil.emailPerfil;
            popular();
        }
        //Método para popular combobox
        private void popular()
        {
            try
            {
                var dao = new Escola();
                Escolas = new ObservableCollection<Escola>();
                dao.RetornaEscolaPorMunicipio(Escolas, perfil.cidadePerfil);
                var bdao = new Bncc();
                Bncc = new ObservableCollection<Bncc>();
                bdao.retornaArea(Bncc);
            }
            catch (SQLiteException erro)
            {
                erro.Message.ToString();
            }
        }

        private void btnEntrar_Click(object sender, RoutedEventArgs e)
        {
            professor.Perfil_idPerfil = perfil.idPerfil;
            
            Bncc bncc = (Bncc)cbArea.SelectionBoxItem;
            Escola escola = (Escola)cbEscola.SelectionBoxItem;
            


            try
            {

                //Inserir Professor
                ProfessorDao profedao = new ProfessorDao();
                professor.idProfessor = (int)profedao.InserirProfessor(professor.Perfil_idPerfil);
                perfil.Perfil_idProfe = professor.idProfessor;
                var pdao = new PerfilDao();
                pdao.CadastraPerfilProfessor(perfil);


                //cadastro Professor_Escola

                Professor_escolas objPE = new Professor_escolas();
                objPE.Escola_idEscola = escola.Codigo_da_Escola;
                objPE.Professor_idProfessor = professor.idProfessor;
                objPE.Professor_Area = bncc.area;
                var pfdao = new Professor_escolas();
                pfdao.InserirProfessorEscola(objPE.Professor_idProfessor, objPE.Professor_Area, objPE.Escola_idEscola);

                //cadastro Usuario
                UsuarioDao udao = new UsuarioDao();
                
                usuario.nomeUsuario = perfil.emailPerfil;
                usuario.senhaUsuario = pwdSenha.Password;
                usuario.Perfil_idProfe = professor.idProfessor;
                usuario.Perfil_idPerfil = perfil.idPerfil;
                udao.InserirUsuario(usuario);
            }

            catch (SQLiteException erro)
            {
                erro.Message.ToString();
            }
            this.Frame.Navigate(typeof(PerfilProfessor), professor);
        }
    }
}
