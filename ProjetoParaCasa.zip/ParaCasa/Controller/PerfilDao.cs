﻿using ParaCasa.Models;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Controller
{
    class PerfilDao
    {
        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");



        public long InserirPerfil(string nomePerfil, string emailPerfil, string cidadePerfil, string estadoPerfil, DateTimeOffset dataNascPerfil)
        {
            try
            {
                var date = dataNascPerfil.Date.ToString("yyyy-MM-dd");
                using (var custstmt = conn.Prepare("INSERT INTO Perfil (nomePerfil, emailPerfil, cidadePerfil, estadoPerfil, dataNascPerfil) VALUES (?,?,?,?,?)"))
                {
                    custstmt.Bind(1, nomePerfil);
                    custstmt.Bind(2, emailPerfil);
                    custstmt.Bind(3, cidadePerfil);
                    custstmt.Bind(4, estadoPerfil);
                    custstmt.Bind(5, date);
                    custstmt.Step();
                }
            }
            catch (SQLiteException erro)
            {
                erro.Message.ToString();

            }

            return conn.LastInsertRowId();
        }



        public List<Perfil> retornaPerfil()
        {
            List<Perfil> listaPerfil = new List<Perfil>();

            using (var statement = conn.Prepare("SELECT CAST(idPerfil as INTEGER), nomePerfil, emailPerfil, cidadePerfil, estadoPerfil, dataNascPerfil, Perfil_idProfe, Perfil_idAluno FROM PERFIL"))
            {

                while (SQLiteResult.DONE != statement.Step())
                {
                    Perfil perfil = new Perfil()
                    {
                        idPerfil = (long)statement[0],
                        nomePerfil = (string)statement[1],
                        emailPerfil = (string)statement[2],
                        cidadePerfil = (string)statement[3],
                        estadoPerfil = (string)statement[4],
                        dataNascPerfil = (DateTime)statement[5],
                        Perfil_idProfe = (long)statement[6],
                        Perfil_idAluno = (long)statement[7]
                    };
                    listaPerfil.Add(perfil);
                }
            }
            return listaPerfil;
        }

        internal void CadastraPerfilProfessor(Perfil perfil)
        {
            try
            {
                using (var custstmt = conn.Prepare("UPDATE Perfil SET Perfil_idProfe=? WHERE idPerfil = ?"))
                {

                    custstmt.Bind(1, perfil.Perfil_idProfe);
                    custstmt.Bind(2, perfil.idPerfil);
                    custstmt.Step();

                }
            }
            catch (SQLiteException erro)
            {
                erro.Message.ToString();
            }
        }


        internal void CadastraPerfilAluno(Perfil perfil)
        {


            try
            {
                using (var custstmt = conn.Prepare("UPDATE Perfil SET Perfil_idAluno=? WHERE idPerfil = ?"))
                {

                    custstmt.Bind(1, perfil.Perfil_idAluno);
                    custstmt.Bind(2, perfil.idPerfil);
                    custstmt.Step();

                }
            }
            catch (SQLiteException erro)
            {
                erro.Message.ToString();
            }


        }
    }
}