﻿using ParaCasa.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLitePCL;
using Windows.UI.Xaml.Controls;
using Windows.UI;
using System.Collections.ObjectModel;

namespace ParaCasa.Controller
    

{
    public class UsuarioDao
    {
        
       SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");

        public long InserirUsuario(Usuario usuario)
        {
            try
            {
                using (var custstmt = conn.Prepare("INSERT INTO USUARIO (nomeUsuario, senhaUsuario, Perfil_idPerfil, Perfil_idAluno, Perfil_idProfe ) VALUES ( ?,?,?,?,?)"))
                {
                    custstmt.Bind(1, usuario.nomeUsuario);
                    custstmt.Bind(2, usuario.senhaUsuario);
                    custstmt.Bind(3, usuario.Perfil_idPerfil);
                    custstmt.Bind(4, usuario.Perfil_idAluno);
                    custstmt.Bind(5, usuario.Perfil_idProfe);
                    custstmt.Step();
                }
            }
            catch (SQLiteException erro )
            {
                erro.Message.ToString(); 
            }

            return conn.LastInsertRowId();
        }
        public void RetornaTodosUsuarios(ObservableCollection<Usuario> users)
        {
            var allusers = retornaUsuarios();
            users.Clear();
            allusers.ForEach(p => users.Add(p));
        }


        public List<Usuario> retornaUsuarios()
        {
            var listaUsuario = new List<Usuario>();

            using (var statement = conn.Prepare("SELECT CAST(idUsuario as INTEGER), nomeUsuario, senhaUsuario , Perfil_idProfe, Perfil_idAluno  FROM USUARIO"))
            {

                while (SQLiteResult.DONE != statement.Step())
                {
                    Usuario usuario = new Usuario()
                    {
                        idUsuario = (long)statement[0],
                        nomeUsuario = (string)statement[1],
                        senhaUsuario = (string)statement[2],
                        Perfil_idProfe = (long)statement[3],
                        Perfil_idAluno = (long)statement[4]
                    };
                    listaUsuario.Add(usuario);
                }
            }
            return listaUsuario;
        }

        public void DeleteUsuario(long idUsuario)
        {
            using (var statement = conn.Prepare("DELETE FROM Usuario WHERE idUsuario = ?"))
            {
                statement.Bind(1, idUsuario);
                statement.Step();
            }
        }
       /* public Boolean BuscaUsuario(string nomeUsuario, string senhaUsuario)
        {
            
            
                using (var statement = conn.Prepare("SELECT idUsuario, nomeUsuario, senhaUsuario, Perfil_idProfe, Perfil_idAluno FROM USUARIO WHERE nomeUsuario = ? AND senhaUsuario = ?"))
                {
                try
                {
                    statement.Bind(1, nomeUsuario);
                    statement.Bind(2, senhaUsuario);
                    while (SQLiteResult.DONE != statement.Step())
                    {
                       Usuario usuario = new Usuario()
                        {
                            idUsuario = (long)statement[0],
                            nomeUsuario = (string)statement[1],
                            senhaUsuario = (string)statement[2],
                            Perfil_idProfe = (long)statement[3],
                            Perfil_idAluno = (long)statement[4]
                        };

                    }
                    if (usuario != null)
                        return true;
                }
                catch (SQLiteException erro)
                {
                    erro.Message.ToString();
                }
            }
            
           
            return false;
        }*/
        public bool logarUsuario (string nomeUsuario, string senhaUsuario) 
        {
            var listaUsuario = new List<Usuario>();

            try {
                using (var statement = conn.Prepare("SELECT idUsuario, nomeUsuario, senhaUsuario, Perfil_idProfe, Perfil_idAluno FROM USUARIO WHERE nomeUsuario = ? AND senhaUsuario = ?"))
                {
                    statement.Bind(1, nomeUsuario);
                    statement.Bind(2, senhaUsuario);

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Usuario usuario = new Usuario()
                        {
                            idUsuario = (long)statement[0],
                            nomeUsuario = (string)statement[1],
                            senhaUsuario = (string)statement[2],
                            Perfil_idProfe = (long)statement[3],
                            Perfil_idAluno = (long)statement[4]
                        };
                        listaUsuario.Add(usuario);
                        
                    }
                }
                
            }
            catch (SQLiteException erro)
            {
                erro.Message.ToString();
            }

            if (listaUsuario.Count >= 1)
            {
                return true;
            }
            else
                return false;
            
        }

        public Usuario dadosUsuario(Usuario usuario)
        {
                   

            Usuario user = new Usuario();

            try
            {
                using (var statement = conn.Prepare("SELECT idUsuario, nomeUsuario, senhaUsuario, Perfil_idProfe, Perfil_idAluno FROM USUARIO WHERE nomeUsuario = ? AND senhaUsuario = ?"))
                {
                    statement.Bind(1, usuario.nomeUsuario);
                    statement.Bind(2, usuario.senhaUsuario);

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        user = new Usuario()
                        {
                            idUsuario = (long)statement[0],
                            nomeUsuario = (string)statement[1],
                            senhaUsuario = (string)statement[2],
                            Perfil_idProfe = (long)statement[3],
                            Perfil_idAluno = (long)statement[4]
                        };

                    }
                
                }

            }
            catch (SQLiteException e)
            {
                e.Message.ToString();
            }
            return user;
        }

        /* public void AtualizaSenha(Usuario usuario)
         {
             //See if the customer already exists
             var exiteUsuario = BuscaUsuario(usuario.idUsuario);
             if (exiteUsuario != null)
             {
                 using (var custstmt = conn.Prepare("UPDATE Usuario SET senhaUsuario=?, WHERE Id=?"))
                 {
                     //NOTE when using anonymous parameters the first has an index of 1, not 0.
                     custstmt.Bind(1, usuario.senhaUsuario);
                     custstmt.Bind(4, usuario.idUsuario);
                     custstmt.Step();

                 }
             }
         }*/



    }
}

