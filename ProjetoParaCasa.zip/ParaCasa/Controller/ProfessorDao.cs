﻿using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParaCasa.Models;

namespace ParaCasa.Controller
{
    class ProfessorDao
    {
        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");



        public long InserirProfessor(long Perfil_idPerfil )
        {
            try
            {
                using (var custstmt = conn.Prepare("INSERT INTO Professor (Perfil_idPerfil) VALUES (?)"))
                {
                    custstmt.Bind(1, Perfil_idPerfil);
                    custstmt.Step();
                }
            }

            catch (Exception erro)
            {
                erro.Message.ToString();
            }

            return conn.LastInsertRowId();
        }

        public string retornaNome(long idProfessor)
        {
            string nomeProfessor;
            using (var stmt = conn.Prepare("SELECT perfil.nomePerfil FROM perfil INNER JOIN Professor on perfil.Perfil_idProfe = professor.idProfessor WHERE idProfessor = ?"))
            {
                stmt.Bind(1, idProfessor);
                stmt.Step();

                nomeProfessor = (string)stmt[0];
            }
            return nomeProfessor;
        }
        public string retornaEscola(long idProfessor)
        {
            string nomeEscola;
            using (var stmt = conn.Prepare("SELECT escolas.Nome_da_Escola FROM escolas INNER JOIN professor_Escolas on escolas.Codigo_da_Escola = professor_Escolas.Escola_idEscola WHERE idProfessor = ?"))
            {
                stmt.Bind(1, idProfessor);
                stmt.Step();

                nomeEscola = (string)stmt[0];
            }
            return nomeEscola;
        }

        internal Perfil retornaPerfilProfessor(long idProfessor)
        {
            Perfil perfil = new Perfil();
            try
            {
                using (var statement = conn.Prepare("SELECT CAST(idPerfil as INTEGER), nomePerfil, emailPerfil, cidadePerfil, estadoPerfil, dataNascPerfil, Perfil_idProfe, Perfil_idAluno FROM PERFIL WHERE Perfil_idProfessor = ?"))
                {
                    statement.Bind(1, idProfessor);
                    statement.Step();
                    while (SQLiteResult.DONE != statement.Step())
                    {
                        perfil = new Perfil()
                        {
                            idPerfil = (long)statement[0],
                            nomePerfil = (string)statement[1],
                            emailPerfil = (string)statement[2],
                            cidadePerfil = (string)statement[3],
                            estadoPerfil = (string)statement[4],
                            dataNascPerfil = (DateTimeOffset)statement[5],
                            Perfil_idProfe = (long)statement[6],
                            Perfil_idAluno = (long)statement[7]
                        };

                    }

                }

            }
            catch (SQLiteException e)
            {
                e.Message.ToString();
            }
            return perfil;
        }

        internal Professor BuscaProfessor(int  idProfessor)
        {
            
            Professor professor = null;
            using (var statement = conn.Prepare("SELECT idProfessor, Perfil_idPerfil FROM PROFESSOR WHERE idProfessor = ?"))
            {
                statement.Bind(1, idProfessor);
                statement.Step();
                professor = new Professor()
                {
                    idProfessor = (long)statement[0],
                    Perfil_idPerfil = (long)statement[1]
                };
            }
            return professor;
        }
    }
}
