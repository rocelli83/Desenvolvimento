﻿using ParaCasa.Models;
using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Controller
{
    class AlunoDao
    {
        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");



        public long InserirAluno(long Perfil_idPerfil, string matriculaAluno, long anoAluno, long Escola_idEscola)
        {
            try
            {
                using (var custstmt = conn.Prepare("INSERT INTO ALUNO (Perfil_idPerfil, matriculaAluno, anoAluno, Escola_idEscola) VALUES (?,?,?,?)"))
                {
                    custstmt.Bind(1, Perfil_idPerfil);
                    custstmt.Bind(2, matriculaAluno);
                    custstmt.Bind(3, anoAluno);
                    custstmt.Bind(4, Escola_idEscola);
                    custstmt.Step();
                }
            }
            catch (Exception erro)
            {
                erro.Message.ToString();
            }

            return conn.LastInsertRowId();

        }
        public List<Aluno> retornaALuno()
        {
            List<Aluno> listaAluno = new List<Aluno>();

            using (var statement = conn.Prepare("SELECT CAST(idAluno as INTEGER), matriculaAluno, Escola_idEscola , Perfil_idPerfil FROM ALUNO"))
            {

                while (SQLiteResult.DONE != statement.Step())
                {
                    Aluno aluno = new Aluno()
                    {
                        idAluno = (int)statement[0],
                        matriculaAluno = (string)statement[1],
                        Escola_idEscola = (int)statement[2],
                        Perfil_idPerfil = (int)statement[3]
                    };
                    listaAluno.Add(aluno);
                }
            }
            return listaAluno;
        }

        public Aluno BuscaAluno(long idAluno)
        {
            Aluno aluno = null;
            using (var statement = conn.Prepare("SELECT idAluno, matriculaAluno, Escola_idEscola, Perfil_idPerfil FROM ALUNO WHERE idAluno = ?"))
            {
                statement.Bind(1, idAluno);
                statement.Step();
                aluno = new Aluno()
                {
                    idAluno = (long)statement[0],
                    matriculaAluno = (string)statement[1],
                    Escola_idEscola = (long)statement[2],
                    Perfil_idPerfil = (long)statement[3]
                };
            }
            return aluno;
        }

        public string retornaEscola(long idAluno)
        {
            string nomeEscola;
            using (var stmt = conn.Prepare("SELECT escolas.Nome_da_Escola FROM escolas INNER JOIN aluno on escolas.Codigo_da_Escola = aluno.Escola_idEscola WHERE idAluno = ?"))
            {
                stmt.Bind(1, idAluno);
                stmt.Step();

                nomeEscola = (string)stmt[0];
            }
            return nomeEscola;
        }
        public string retornaNome(long idAluno)
        {
            string nomeAluno;
            using (var stmt = conn.Prepare("SELECT perfil.nomePerfil FROM perfil INNER JOIN aluno on perfil.Perfil_idAluno = aluno.idAluno WHERE idAluno = ?"))
            {
                stmt.Bind(1, idAluno);
                stmt.Step();

                nomeAluno = (string)stmt[0];
            }
            return nomeAluno;
        }

        public Perfil retornaPerfilAluno(long idAluno)
        {
            Perfil perfil = new Perfil();
            try
            {
                using (var statement = conn.Prepare("SELECT CAST(idPerfil as INTEGER), nomePerfil, emailPerfil, cidadePerfil, estadoPerfil, dataNascPerfil, Perfil_idProfe, Perfil_idAluno FROM PERFIL WHERE Perfil_idAluno = ?"))
            {
                statement.Bind(1, idAluno);
                statement.Step();
                    while (SQLiteResult.DONE != statement.Step())
                    {
                        perfil = new Perfil()
                        {
                            idPerfil = (int)statement[0],
                            nomePerfil = (string)statement[1],
                            emailPerfil = (string)statement[2],
                            cidadePerfil = (string)statement[3],
                            estadoPerfil = (string)statement[4],
                            dataNascPerfil = (DateTimeOffset)statement[5],
                            Perfil_idProfe = (int)statement[6],
                            Perfil_idAluno = (int)statement[7]
                        };

                    }

                }

            }
            catch (SQLiteException e)
            {
                e.Message.ToString();
            }
            return perfil;
        }

         
                
    }
}
