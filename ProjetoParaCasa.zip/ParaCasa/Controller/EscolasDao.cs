﻿using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParaCasa.Models;
using System.Collections.ObjectModel;

namespace ParaCasa.Controller
{
    class EscolasDao
    {
        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");

        

        public void RetornaTodasEscolas(ObservableCollection<Escola> escolas)
        {
            var allEscolas = retornaEscolas();
            escolas.Clear();
            allEscolas.ForEach(p => escolas.Add(p));
        }
        public void RetornaEscolaPorMunicipio (ObservableCollection<Escola> escolas, string municipio)
        {
            var allusers = retornaEscolas();
            var filtroEscola = allusers.Where(p => p.municipio == municipio).ToList();
            escolas.Clear();
            filtroEscola.ForEach(p => escolas.Add(p));
        }

        public List<Escola> retornaEscolas()
        {
            List<Escola> listaEscolas = new List<Escola>();
            try
            {
                using (var statement = conn.Prepare("SELECT Codigo_da_Escola, Municipio, Nome_da_Escola, Dependencia_Administrativa, Localizacao, Endereco, Numero, Bairro, CEP, DDD, Telefone  FROM ESCOLAS"))
                {

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Escola escola = new Escola()
                        {
                            Codigo_da_Escola = (long)statement[0],
                            municipio = (string)statement[1],
                            nome_da_Escola = (string)statement[2],
                            dependencia_Administrativa = (string)statement[3],
                            localizacao = (string)statement[4],
                            endereco = (string)statement[5],
                            numero = (string)statement[6],
                            bairro = (string)statement[7],
                            cep = (long)statement[8],
                            ddd = (string)statement[9],
                            telefone = (string)statement[10]
                        };
                        listaEscolas.Add(escola);
                    }
                }
            }
            catch (Exception)
            {     // TODO: Handle error
            }
            return listaEscolas;
        }
    }
}
