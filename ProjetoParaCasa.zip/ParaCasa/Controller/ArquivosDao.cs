﻿using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Controller
{
    class ArquivosDao
    {
        

        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");



        public long InserirArquivo(long Professor_idProfessor, string Bncc_codBncc, string localArquivo)
        {
            try
            {
                using (var custstmt = conn.Prepare("INSERT INTO ARQUIVOS (Professor_idProfessor, Bncc_codBncc, localArquivo) VALUES (?,?,?)"))
                {
                    custstmt.Bind(1, Professor_idProfessor);
                    custstmt.Bind(2, Bncc_codBncc);
                    custstmt.Bind(3, localArquivo);
                    custstmt.Step();
                }
            }
            catch (Exception)
            {     // TODO: Handle error
            }

            return conn.LastInsertRowId();

        }
    }
}
