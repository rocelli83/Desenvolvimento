﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    public class Aluno
    {
        public long idAluno { get; set; }
        public long Escola_idEscola { get; set; }
        public string matriculaAluno { get; set; }
        public long anoAluno { get; set; }
        public long Perfil_idPerfil { get; set; }
    }
}
