﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    public class Usuario
    {
        public long idUsuario { get; set; }
        public string nomeUsuario { get; set; }
        public string senhaUsuario { get; set; }
        public long Perfil_idProfe { get; set; }
        public long Perfil_idAluno { get; set; }
        public long Perfil_idPerfil { get; set; }


    }
}
