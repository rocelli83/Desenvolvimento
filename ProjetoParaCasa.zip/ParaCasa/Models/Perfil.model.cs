﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    public class Perfil

    {

           public long idPerfil { get; set; }
           public string nomePerfil { get; set; }
           public string emailPerfil { get; set; }
           public string cidadePerfil { get; set; }
           public string estadoPerfil { get; set; }
           public DateTimeOffset dataNascPerfil { get; set; }
           public long Perfil_idProfe { get; set; }
           public long Perfil_idAluno { get; set; }

    }
}
