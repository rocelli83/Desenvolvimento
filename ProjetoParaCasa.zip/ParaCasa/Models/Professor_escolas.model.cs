﻿using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    class Professor_escolas
    {
        public long idProfessorEscola { get; set; }
        public long Professor_idProfessor { get; set; }
        public long Escola_idEscola { get; set; }
        public string Professor_Area { get; set; }


        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");



        public long InserirProfessorEscola(long Professor_idProfessor, string Professor_Area, long Escola_idEscola)
        {
            try
            {
                using (var custstmt = conn.Prepare("INSERT INTO Professor_Escolas ( Professor_idProfessor, Professor_Area, Escola_idEscola) VALUES (?,?,?)"))
                {
                    custstmt.Bind(1, Professor_idProfessor);
                    custstmt.Bind(2, Professor_Area);
                    custstmt.Bind(3, Escola_idEscola);
                   
                    custstmt.Step();
                }
            }
            catch (Exception erro)
            {
                erro.Message.ToString();
            }

            return conn.LastInsertRowId();

        }

       
             public string retornaArea(long idProfessor)
        {
            string nomeArea;
            using (var stmt = conn.Prepare("select Professor_Area from Professor_Escolas where Professor_idProfessor = ? "))
            {
                stmt.Bind(1, idProfessor);
                stmt.Step();

                nomeArea = (string)stmt[0];
            }
            return nomeArea;
        }

    }
}
