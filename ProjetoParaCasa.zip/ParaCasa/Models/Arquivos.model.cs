﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    public class Arquivos
    {
        private long idArquivo { get; set; }
        private long Professor_idProfessor { get; set; }
        private string Bncc_codBncc { get; set; }
        private string localArquivo { get; set; }
    }
}
