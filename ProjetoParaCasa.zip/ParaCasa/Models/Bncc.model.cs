﻿using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    public class Bncc
    {
        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");

        public string codigo { get; set; }
        public string area { get; set; }
        public string materia { get; set; }
        public long ano { get; set; }
        public string conteudo { get; set; }


        public void retornaArea(ObservableCollection<Bncc> bncc)
        {
            var allBase = escolhaArea();
            bncc.Clear();
            allBase.ForEach(p => bncc.Add(p));
        }
        public List<Bncc> escolhaArea()
        {

            List<Bncc> listaAreas = new List<Bncc>();
            try
            {
                using (var statement = conn.Prepare("select * from ListaAreasBncc"))
                {

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Bncc bncc = new Bncc()
                        {
                            area = (string)statement[0]
                        };
                        listaAreas.Add(bncc);

                    }
                }
            }

            catch (Exception erro)
            {
                erro.Message.ToString();
            }
            return listaAreas;
        }
        public void retornaMateria(ObservableCollection<Bncc> bncc)
        {
            var allBase = escolhaMateria();
            bncc.Clear();
            allBase.ForEach(p => bncc.Add(p));
        }
        public List<Bncc> escolhaMateria()
        {

            List<Bncc> listaMaterias = new List<Bncc>();
            try
            {
                using (var statement = conn.Prepare("SELECT DISTINCT area, materia, ano FROM Bncc"))
                {

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Bncc bncc = new Bncc()
                        {
                            area = (string)statement[0],
                            materia = (string)statement[0],
                            ano = (long)statement[0]
                        };
                        listaMaterias.Add(bncc);

                    }
                }
            }

            catch (Exception erro)
            {
                erro.Message.ToString();
            }
            return listaMaterias;
        }


        public void RetornaTodaBase(ObservableCollection<Bncc> bncc)
        {
            var allBase = retornaBncc();
            bncc.Clear();
            allBase.ForEach(p => bncc.Add(p));
        }
        public List<Bncc> retornaBncc()
        {
            List<Bncc> listaBase = new List<Bncc>();
            try
            {
                using (var statement = conn.Prepare("SELECT codigo, area, materia, ano, conteudo FROM Bncc"))
                {

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Bncc bncc = new Bncc()
                        {

                            codigo = (string)statement[0],
                            area = (string)statement[1],
                            materia = (string)statement[2],
                            ano = (long)statement[3],
                            conteudo = (string)statement[4],

                        };
                        listaBase.Add(bncc);
                    }
                }
            }
            catch (Exception erro)
            {
                erro.Message.ToString();
            }
            return listaBase;
        }
    }
}
