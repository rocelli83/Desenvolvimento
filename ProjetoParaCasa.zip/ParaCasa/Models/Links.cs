﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    class Links
    {
        private string filePath(string area)
    {
            // Recebe a string AREA 
            //e devolve o caminho do 
            //arquivo correspondente
        
            string file = "BNCC.txt";

            area = area.ToUpper();
            area = area.Remove('\n');

        switch (area)
        {
            case "ARTE":
                    file = "/Assets/Materials/ARTE.txt";
                    break;
                case "BIOLOGIA":
                    file = "/Assets/Materials/BIO.txt";
                    break;
                case "EDUCACAO FISICA":
                    file = "/Assets/Materials/EDFIS.txt";
                    break;
                case "FILOSOFIA":
                    file = "/Assets/Materials/FILO.txt";
                    break;
                case "FISICA":
                    file = "/Assets/Materials/FIS.txt";
                    break;
                case "GEOGRAFIA":
                    file = "/Assets/Materials/GEO.txt";
                    break;
                case "HISTORIA":
                    file = "/Assets/Materials/HIST.txt";
                    break;
                case "LINGUA ESTRANGEIRA MODERNA":
                    file = "/Assets/Materials/LEM.txt";
                    break;
                case "MATEMATICA":
                    file = "/Assets/Materials/MAT.txt";
                    break;
                case "LINGUA PORTUGUESA":
                    file = "/Assets/Materials/PORT.txt";
                    break;
                case "QUIMICA":
                    file = "/Assets/Materials/QUIM.txt";
                    break;
                case "SOCIOLOGIA":
                    file = "/Assets/Materials/SOCIO.txt";
                break;
                default:
                    file = "/Assets/Materials/BNCC.txt";
                break;
        }

            return file;
        }

        public string randomLink(string area)
        {
            // Recebe a string AREA 
            //e devolve um link aleatório
            //do arquivo correspondente

            var path = filePath(area);
            var lines = File.ReadAllLines(path);
            var r = new Random();
            var randomLineNumber = r.Next(0, lines.Length - 1);
            var line = lines[randomLineNumber];

            line = line.ToString();

            return line;
        }
    }
}
