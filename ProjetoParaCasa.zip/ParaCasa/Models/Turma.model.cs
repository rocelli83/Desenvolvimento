﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    public class Turma
    {
        private long idTurma { get; set; }
        private long Professor_idProfessor { get; set; }
        private long Aluno_idAluno { get; set; }
        private string nomeTurma { get; set; }
    }
}
