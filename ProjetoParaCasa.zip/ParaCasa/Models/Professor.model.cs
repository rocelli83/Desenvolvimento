﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    public class Professor
    {
        public long idProfessor { get; set; }
        public long Perfil_idPerfil { get; set; }
    }
}
