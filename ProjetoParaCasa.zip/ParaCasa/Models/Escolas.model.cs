﻿using SQLitePCL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParaCasa.Models
{
    

    public class Escola
    {
        SQLiteConnection conn = new SQLiteConnection("dbparacasa.db");

        public long Codigo_da_Escola { get; set; }
        public string municipio { get; set; }
        public string nome_da_Escola { get; set; }
        public string dependencia_Administrativa { get; set; }
        public string localizacao { get; set; }
        public string endereco { get; set; }
        public string numero { get; set; }
        public string bairro { get; set; }
        public long cep { get; set; }
        public string ddd { get; set; }
        public string telefone { get; set; }


        public void retornaMunicipio(ObservableCollection<Escola> escolas)
        {
            var allEscolas = escolhaMunicipio();
            escolas.Clear();
            allEscolas.ForEach(p => escolas.Add(p));
        }



        public void RetornaTodasEscolas(ObservableCollection<Escola> escolas)
        {
            var allEscolas = retornaEscolas();
            escolas.Clear();
            allEscolas.ForEach(p => escolas.Add(p));
        }
        public void RetornaEscolaPorMunicipio(ObservableCollection<Escola> escolas, string selecionadoMunicipio)
        {
            var filtroEscola = retornaEscolasDoMunicipio(selecionadoMunicipio);
            escolas.Clear();
            filtroEscola.ForEach(p => escolas.Add(p));
        }


        public List<Escola> escolhaMunicipio()
        {

            List<Escola> listaMunicipios = new List<Escola>();
            try
            {
                using (var statement = conn.Prepare("select * from ListaMunicipios"))
                {

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Escola escola = new Escola()
                            {
                            municipio = (string)statement[0]
                            };
                        listaMunicipios.Add(escola);

                    }
                }
            }

            catch (Exception erro)
            {
                erro.Message.ToString();
            }
            return listaMunicipios;
        }
        public List<Escola> retornaEscolasDoMunicipio(string selecionadoMunicipio)
        {
            List<Escola> listaEscolas = new List<Escola>();
            try
            {
                using (var statement = conn.Prepare("SELECT Codigo_da_Escola, Municipio, Nome_da_Escola FROM ESCOLAS WHERE Municipio = ?"))
                {
                    statement.Bind(1, selecionadoMunicipio);

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Escola escola = new Escola()
                        {
                            Codigo_da_Escola = (long)statement[0],
                            municipio = (string)statement[1],
                            nome_da_Escola = (string)statement[2],

                        };
                        listaEscolas.Add(escola);
                    }
                }
            }
            catch (Exception)
            {     // TODO: Handle error
            }
            return listaEscolas;
        }

        public List<Escola> retornaEscolas()
        {
            List<Escola> listaEscolas = new List<Escola>();
            try
            {
                using (var statement = conn.Prepare("SELECT Codigo_da_Escola, Municipio, Nome_da_Escola FROM ESCOLAS"))
                {

                    while (SQLiteResult.DONE != statement.Step())
                    {
                        Escola escola = new Escola()
                        {
                            Codigo_da_Escola = (long)statement[0],
                            municipio = (string)statement[1],
                            nome_da_Escola = (string)statement[2],
                           
                        };
                        listaEscolas.Add(escola);
                    }
                }
            }
            catch (Exception)
            {     // TODO: Handle error
            }
            return listaEscolas;
        }
        public Escola BuscaEscola(string nome_da_Escola)
        {
            Escola escola = null;
            try {
                using (var statement = conn.Prepare("SELECT Codigo_da_Escola, municipio, nome_da_Escola  FROM Escolas WHERE nome_da_Escola = ?"))
                {
                    statement.Bind(1, nome_da_Escola);
                    statement.Step();
                    escola = new Escola()
                    {
                        Codigo_da_Escola = (long)statement[0],
                        municipio = (string)statement[1],
                        nome_da_Escola = (string)statement[2]


                    };
                }
            }
            catch (Exception)
            {     // TODO: Handle error
            }
            return escola;
        }
    }
}
